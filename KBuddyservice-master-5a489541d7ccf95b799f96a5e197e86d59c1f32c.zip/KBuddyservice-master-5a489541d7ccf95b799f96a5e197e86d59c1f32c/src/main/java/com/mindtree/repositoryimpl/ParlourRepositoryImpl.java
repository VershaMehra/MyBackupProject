package com.mindtree.repositoryimpl;

import java.sql.SQLException;
import java.util.List;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.mindtree.entity.Parlour;
import com.mindtree.repository.ParlourRepository;

@Repository(value = "parlourRepository")
public class ParlourRepositoryImpl extends GenericRepositoryHibernateImpl<Parlour, Integer> implements ParlourRepository {
	
	
	@Override
	@Transactional public int addParlour(Parlour parlour) throws SQLException {
		hibernateTemplate.save(parlour);
		return parlour.getId();
	}
		
	@Override
	@Transactional public List<Parlour> findAllParlourItems() throws SQLException {
		return getAllEntities(Parlour.class);
		//		return null;
	}

	@Override
	@Transactional public Boolean updateParlour(Parlour parlour) throws SQLException {
		updateEntity(parlour);
		return true;
	}
	
	@Override
	@Transactional public Boolean removeParlour(Parlour parlour) throws SQLException {
		deleteEntity(parlour);
		return true;
	}
	
}
