package com.mindtree.repositoryimpl;

import java.sql.SQLException;
import java.util.List;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.mindtree.entity.Medicine;
import com.mindtree.repository.MedicineRepository;

@Repository(value = "medicineRepository")
public class MedicineRepositoryImpl extends GenericRepositoryHibernateImpl<Medicine, Integer> implements MedicineRepository {
	
	
	@Override
	@Transactional public int addMedicine(Medicine medicine) throws SQLException {
		hibernateTemplate.save(medicine);
		return medicine.getId();
	}
		
	@Override
	@Transactional public List<Medicine> findAllMedicineItems() throws SQLException {
		return getAllEntities(Medicine.class);
		//		return null;
	}

	@Override
	@Transactional public Boolean updateMedicine(Medicine medicine) throws SQLException {
		updateEntity(medicine);
		return true;
	}
	
	@Override
	@Transactional public Boolean removeMedicine(Medicine medicine) throws SQLException {
		deleteEntity(medicine);
		return true;
	}
	
}
