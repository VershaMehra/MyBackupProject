package com.mindtree.repositoryimpl;

import java.sql.SQLException;
import java.util.List;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.mindtree.entity.Malls;
import com.mindtree.repository.MallsRepository;

@Repository(value = "mallsRepository")
public class MallsRepositoryImpl extends GenericRepositoryHibernateImpl<Malls, Integer> implements MallsRepository {
	
	
	@Override
	@Transactional public int addMalls(Malls malls) throws SQLException {
		hibernateTemplate.save(malls);
		return malls.getId();
	}
		
	@Override
	@Transactional public List<Malls> findAllMallsItems() throws SQLException {
		return getAllEntities(Malls.class);
		//		return null;
	}

	@Override
	@Transactional public Boolean updateMalls(Malls malls) throws SQLException {
		updateEntity(malls);
		return true;
	}
	
	@Override
	@Transactional public Boolean removeMalls(Malls malls) throws SQLException {
		deleteEntity(malls);
		return true;
	}
	
}
