package com.mindtree.repositoryimpl;

import java.sql.SQLException;
import java.util.List;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.mindtree.entity.Food;
import com.mindtree.repository.FoodRepository;

@Repository(value = "foodRepository")
public class FoodRepositoryImpl extends GenericRepositoryHibernateImpl<Food, Integer> implements FoodRepository {
	
	
	@Override
	@Transactional public int addFood(Food food) throws SQLException {
		hibernateTemplate.save(food);
		return food.getId();
	}
		
	@Override
	@Transactional public List<Food> findAllFoodItems() throws SQLException {
		return getAllEntities(Food.class);
		//		return null;
	}

	@Override
	@Transactional public Boolean updateFood(Food food) throws SQLException {
		updateEntity(food);
		return true;
	}
	
	@Override
	@Transactional public Boolean removeFood(Food food) throws SQLException {
		deleteEntity(food);
		return true;
	}
	
}
