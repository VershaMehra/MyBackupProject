package com.mindtree.repositoryimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.mindtree.repository.GenericRepository;

@Repository
public class GenericRepositoryHibernateImpl<T, ID> implements GenericRepository<T, ID>{
	
	@Autowired
	protected HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertEntity(T entity) {
		hibernateTemplate.save(entity);
	}

	@Override
	public List<T> getAllEntities(Class<T> clazz) {
		return hibernateTemplate.loadAll(clazz);
	}

	@Override
	public void updateEntity(T entity) {
		hibernateTemplate.update(entity);
	}
	
	@Override
		public List<T> getByQuery(String query, Object... queryParams) {
		return null;
	}
	
	@Override
	public void deleteEntity(T entity) {
		hibernateTemplate.delete(entity);
	}
	
	

}
