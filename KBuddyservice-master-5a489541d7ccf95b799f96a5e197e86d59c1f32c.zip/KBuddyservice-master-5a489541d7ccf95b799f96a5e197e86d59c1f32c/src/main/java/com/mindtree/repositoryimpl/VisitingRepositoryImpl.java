package com.mindtree.repositoryimpl;

import java.sql.SQLException;
import java.util.List;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.mindtree.entity.Visiting;
import com.mindtree.repository.VisitingRepository;

@Repository(value = "visitingRepository")
public class VisitingRepositoryImpl extends GenericRepositoryHibernateImpl<Visiting, Integer> implements VisitingRepository {
	
	
	@Override
	@Transactional public int addVisiting(Visiting visiting) throws SQLException {
		hibernateTemplate.save(visiting);
		return visiting.getId();
	}
		
	@Override
	@Transactional public List<Visiting> findAllVisitingItems() throws SQLException {
		return getAllEntities(Visiting.class);
		//		return null;
	}

	@Override
	@Transactional public Boolean updateVisiting(Visiting visiting) throws SQLException {
		updateEntity(visiting);
		return true;
	}
	
	@Override
	@Transactional public Boolean removeVisiting(Visiting visiting) throws SQLException {
		deleteEntity(visiting);
		return true;
	}
	
}
