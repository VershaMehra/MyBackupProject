package com.mindtree.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mindtree.entity.Medicine;
import com.mindtree.service.MedicineService;

@Controller
@RequestMapping(path = {"/medicine"})
public class MedicineController {
	
	@Autowired
	MedicineService medicineService;

	@RequestMapping(path = {"/addMedicine"}, method = {RequestMethod.POST})
	@ResponseBody public ResponseEntity<Integer> addMedicine(Locale locale, Model model, @RequestBody @Valid Medicine medicine) {
		int id;
		try {
			id = medicineService.addMedicine(medicine);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<Integer>(HttpStatus.EXPECTATION_FAILED);
		} 
		
		return new ResponseEntity<Integer>(id, HttpStatus.CREATED);
	}
	
	@RequestMapping(path = {"/getMedicine"}, method = {RequestMethod.GET}, produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody public ResponseEntity<List<Medicine>> getmedicinevenue(Locale locale, Model model) {
		
		List<Medicine> medicine = null;
		try {
			medicine = medicineService.findAllMedicineItems();
			if (medicine == null || medicine.isEmpty()) {
				return new ResponseEntity<List<Medicine>>(medicine, HttpStatus.NOT_FOUND);				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<List<Medicine>>(medicine, HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<List<Medicine>>(medicine, HttpStatus.OK);
	}
	
	@RequestMapping(path = {"/updateMedicine"}, method = {RequestMethod.PUT}, produces = {MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody public ResponseEntity<String> updateMedicine(Locale locale, Model model, @RequestBody @Valid Medicine medicine) {
		Boolean updatedFlag;
		try {
			updatedFlag = medicineService.updateMedicine(medicine);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Not updated", HttpStatus.EXPECTATION_FAILED);
		}
		if (updatedFlag == null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<String>("updated", HttpStatus.OK);
	}
	
	@RequestMapping(path = {"/deleteMedicine"}, method = {RequestMethod.DELETE}, produces = {MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody public ResponseEntity<String> deleteMedicine(Locale locale, Model model, @RequestParam("id") int medicineId) {
		
		try {
			medicineService.removeMedicine(medicineId);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Not deleted", HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<String>("deleted", HttpStatus.OK);
	
	}

}
