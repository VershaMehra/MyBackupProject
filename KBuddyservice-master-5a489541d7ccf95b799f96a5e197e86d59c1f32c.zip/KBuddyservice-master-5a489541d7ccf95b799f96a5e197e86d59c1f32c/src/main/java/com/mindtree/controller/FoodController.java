package com.mindtree.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mindtree.entity.Food;
import com.mindtree.service.FoodService;

//Testing VKS

@Controller
@RequestMapping(path = {"/food"})
public class FoodController {
	
	@Autowired
	FoodService foodService;

	@RequestMapping(path = {"/addFood"}, method = {RequestMethod.POST})
	@ResponseBody public ResponseEntity<Integer> addFood(Locale locale, Model model, @RequestBody @Valid Food food) {
		int id;
		try {
			id = foodService.addFood(food);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<Integer>(HttpStatus.EXPECTATION_FAILED);
		} 
		
		return new ResponseEntity<Integer>(id, HttpStatus.CREATED);
	}
	
	@RequestMapping(path = {"/getFood"}, method = {RequestMethod.GET}, produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody public ResponseEntity<List<Food>> getfoodvenue(Locale locale, Model model) {
		
		List<Food> food = null;
		try {
			food = foodService.findAllFoodItems();
			if (food == null || food.isEmpty()) {
				return new ResponseEntity<List<Food>>(food, HttpStatus.NOT_FOUND);				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<List<Food>>(food, HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<List<Food>>(food, HttpStatus.OK);
	}
	
	@RequestMapping(path = {"/updateFood"}, method = {RequestMethod.PUT}, produces = {MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody public ResponseEntity<String> updateFood(Locale locale, Model model, @RequestBody @Valid Food food) {
		Boolean updatedFlag;
		try {
			updatedFlag = foodService.updateFood(food);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Not updated", HttpStatus.EXPECTATION_FAILED);
		}
		if (updatedFlag == null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<String>("updated", HttpStatus.OK);
	}
	
	@RequestMapping(path = {"/deleteFood"}, method = {RequestMethod.DELETE}, produces = {MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody public ResponseEntity<String> deleteFood(Locale locale, Model model, @RequestParam("id") int foodId) {
		
		try {
			foodService.removeFood(foodId);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Not deleted", HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<String>("deleted", HttpStatus.OK);
	
	}

}
