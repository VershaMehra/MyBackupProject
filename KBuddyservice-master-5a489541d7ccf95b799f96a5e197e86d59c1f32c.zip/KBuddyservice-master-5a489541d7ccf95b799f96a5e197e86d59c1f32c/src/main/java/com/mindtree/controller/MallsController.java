package com.mindtree.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mindtree.entity.Malls;
import com.mindtree.service.MallsService;

@Controller
@RequestMapping(path = {"/malls"})
public class MallsController {
	
	@Autowired
	MallsService mallsService;

	@RequestMapping(path = {"/addMalls"}, method = {RequestMethod.POST})
	@ResponseBody public ResponseEntity<Integer> addMalls(Locale locale, Model model, @RequestBody @Valid Malls malls) {
		int id;
		try {
			id = mallsService.addMalls(malls);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<Integer>(HttpStatus.EXPECTATION_FAILED);
		} 
		
		return new ResponseEntity<Integer>(id, HttpStatus.CREATED);
	}
	
	@RequestMapping(path = {"/getMalls"}, method = {RequestMethod.GET}, produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody public ResponseEntity<List<Malls>> getmallsvenue(Locale locale, Model model) {
		
		List<Malls> malls = null;
		try {
			malls = mallsService.findAllMallsItems();
			if (malls == null || malls.isEmpty()) {
				return new ResponseEntity<List<Malls>>(malls, HttpStatus.NOT_FOUND);				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<List<Malls>>(malls, HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<List<Malls>>(malls, HttpStatus.OK);
	}
	
	@RequestMapping(path = {"/updateMalls"}, method = {RequestMethod.PUT}, produces = {MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody public ResponseEntity<String> updateMalls(Locale locale, Model model, @RequestBody @Valid Malls malls) {
		Boolean updatedFlag;
		try {
			updatedFlag = mallsService.updateMalls(malls);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Not updated", HttpStatus.EXPECTATION_FAILED);
		}
		if (updatedFlag == null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<String>("updated", HttpStatus.OK);
	}
	
	@RequestMapping(path = {"/deleteMalls"}, method = {RequestMethod.DELETE}, produces = {MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody public ResponseEntity<String> deleteMalls(Locale locale, Model model, @RequestParam("id") int mallsId) {
		
		try {
			mallsService.removeMalls(mallsId);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Not deleted", HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<String>("deleted", HttpStatus.OK);
	
	}

}
