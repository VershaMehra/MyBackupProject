package com.mindtree.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mindtree.entity.Visiting;
import com.mindtree.service.VisitingService;

@Controller
@RequestMapping(path = {"/visiting"})

public class VisitingController {
	
	@Autowired
	VisitingService visitingService;

	@RequestMapping(path = {"/addVisiting"}, method = {RequestMethod.POST})
	@ResponseBody public ResponseEntity<Integer> addVisiting(Locale locale, Model model, @RequestBody @Valid Visiting visiting) {
		int id;
		try {
			id = visitingService.addVisiting(visiting);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<Integer>(HttpStatus.EXPECTATION_FAILED);
		} 
		
		return new ResponseEntity<Integer>(id, HttpStatus.CREATED);
	}
	
	@RequestMapping(path = {"/getVisiting"}, method = {RequestMethod.GET}, produces = {MediaType.APPLICATION_JSON_VALUE})
	@ResponseBody public ResponseEntity<List<Visiting>> getvisitingvenue(Locale locale, Model model) {
		
		List<Visiting> visiting = null;
		try {
			visiting = visitingService.findAllVisitingItems();
			if (visiting == null || visiting.isEmpty()) {
				return new ResponseEntity<List<Visiting>>(visiting, HttpStatus.NOT_FOUND);				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<List<Visiting>>(visiting, HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<List<Visiting>>(visiting, HttpStatus.OK);
	}
	
	@RequestMapping(path = {"/updateVisiting"}, method = {RequestMethod.PUT}, produces = {MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody public ResponseEntity<String> updateVisiting(Locale locale, Model model, @RequestBody @Valid Visiting visiting) {
		Boolean updatedFlag;
		try {
			updatedFlag = visitingService.updateVisiting(visiting);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Not updated", HttpStatus.EXPECTATION_FAILED);
		}
		if (updatedFlag == null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<String>("updated", HttpStatus.OK);
	}
	
	@RequestMapping(path = {"/deleteVisiting"}, method = {RequestMethod.DELETE}, produces = {MediaType.TEXT_PLAIN_VALUE})
	@ResponseBody public ResponseEntity<String> deleteVisiting(Locale locale, Model model, @RequestParam("id") int visitingId) {
		
		try {
			visitingService.removeVisiting(visitingId);
		} catch (SQLException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Not deleted", HttpStatus.EXPECTATION_FAILED);
		}
		return new ResponseEntity<String>("deleted", HttpStatus.OK);
	
	}


}
