package com.mindtree.serviceimpl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.entity.Malls;
import com.mindtree.repository.MallsRepository;
import com.mindtree.service.MallsService;


@Service(value = "mallsService")
public class MallsServiceImpl implements MallsService{
	
	@Autowired
	MallsRepository mallsRepository;
	
	@Override
	public int addMalls(Malls malls) throws SQLException {
		return mallsRepository.addMalls(malls);
	}
	
	@Override
	public List<Malls> findAllMallsItems() throws SQLException {
		return mallsRepository.findAllMallsItems();
	}
	
	@Override
	public Boolean updateMalls(Malls malls) throws SQLException {
		return mallsRepository.updateMalls(malls);
	}
	
	@Override
	public Boolean removeMalls(int id) throws SQLException {
		Malls malls = new Malls();
		malls.setId(id);
		return mallsRepository.removeMalls(malls);
	}
	
	

}
