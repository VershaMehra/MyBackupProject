package com.mindtree.serviceimpl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.entity.Visiting;
import com.mindtree.repository.VisitingRepository;
import com.mindtree.service.VisitingService;


@Service(value = "visitingService")
public class VisitingServiceImpl implements VisitingService{
	
	@Autowired
	VisitingRepository visitingRepository;
	
	@Override
	public int addVisiting(Visiting visiting) throws SQLException {
		return visitingRepository.addVisiting(visiting);
	}
	
	@Override
	public List<Visiting> findAllVisitingItems() throws SQLException {
		return visitingRepository.findAllVisitingItems();
	}
	
	@Override
	public Boolean updateVisiting(Visiting visiting) throws SQLException {
		return visitingRepository.updateVisiting(visiting);
	}
	
	@Override
	public Boolean removeVisiting(int id) throws SQLException {
		Visiting visiting = new Visiting();
		visiting.setId(id);
		return visitingRepository.removeVisiting(visiting);
	}
	
	

}
