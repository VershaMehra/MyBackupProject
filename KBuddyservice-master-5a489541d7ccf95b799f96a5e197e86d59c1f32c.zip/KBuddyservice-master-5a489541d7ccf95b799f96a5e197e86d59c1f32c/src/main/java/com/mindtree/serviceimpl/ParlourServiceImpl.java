package com.mindtree.serviceimpl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.entity.Parlour;
import com.mindtree.repository.ParlourRepository;
import com.mindtree.service.ParlourService;


@Service(value = "parlourService")
public class ParlourServiceImpl implements ParlourService{
	
	@Autowired
	ParlourRepository parlourRepository;
	
	@Override
	public int addParlour(Parlour parlour) throws SQLException {
		return parlourRepository.addParlour(parlour);
	}
	
	@Override
	public List<Parlour> findAllParlourItems() throws SQLException {
		return parlourRepository.findAllParlourItems();
	}
	
	@Override
	public Boolean updateParlour(Parlour parlour) throws SQLException {
		return parlourRepository.updateParlour(parlour);
	}
	
	@Override
	public Boolean removeParlour(int id) throws SQLException {
		Parlour parlour = new Parlour();
		parlour.setId(id);
		return parlourRepository.removeParlour(parlour);
	}
	
	

}
