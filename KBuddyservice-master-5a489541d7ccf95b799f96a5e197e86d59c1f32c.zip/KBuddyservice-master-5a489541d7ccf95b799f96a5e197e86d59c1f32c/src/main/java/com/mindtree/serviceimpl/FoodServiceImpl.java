package com.mindtree.serviceimpl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.entity.Food;
import com.mindtree.repository.FoodRepository;
import com.mindtree.service.FoodService;


@Service(value = "foodService")
public class FoodServiceImpl implements FoodService{
	
	@Autowired
	FoodRepository foodRepository;
	
	@Override
	public int addFood(Food food) throws SQLException {
		return foodRepository.addFood(food);
	}
	
	@Override
	public List<Food> findAllFoodItems() throws SQLException {
		return foodRepository.findAllFoodItems();
	}
	
	@Override
	public Boolean updateFood(Food food) throws SQLException {
		return foodRepository.updateFood(food);
	}
	
	@Override
	public Boolean removeFood(int id) throws SQLException {
		Food food = new Food();
		food.setId(id);
		return foodRepository.removeFood(food);
	}
	
	

}
