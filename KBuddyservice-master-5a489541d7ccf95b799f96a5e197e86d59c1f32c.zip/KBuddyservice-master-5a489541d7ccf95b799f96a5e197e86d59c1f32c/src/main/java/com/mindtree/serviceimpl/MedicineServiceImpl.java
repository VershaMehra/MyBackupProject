package com.mindtree.serviceimpl;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.entity.Medicine;
import com.mindtree.repository.MedicineRepository;
import com.mindtree.service.MedicineService;


@Service(value = "medicineService")
public class MedicineServiceImpl implements MedicineService{
	
	@Autowired
	MedicineRepository medicineRepository;
	
	@Override
	public int addMedicine(Medicine medicine) throws SQLException {
		return medicineRepository.addMedicine(medicine);
	}
	
	@Override
	public List<Medicine> findAllMedicineItems() throws SQLException {
		return medicineRepository.findAllMedicineItems();
	}
	
	@Override
	public Boolean updateMedicine(Medicine medicine) throws SQLException {
		return medicineRepository.updateMedicine(medicine);
	}
	
	@Override
	public Boolean removeMedicine(int id) throws SQLException {
		Medicine medicine = new Medicine();
		medicine.setId(id);
		return medicineRepository.removeMedicine(medicine);
	}
	
	

}
