package com.mindtree.service;

import java.sql.SQLException;
import java.util.List;


import com.mindtree.entity.Medicine;

public interface MedicineService {
	public int addMedicine(Medicine medicine) throws SQLException;
	public List<Medicine> findAllMedicineItems() throws SQLException;
	public Boolean updateMedicine(Medicine medicine) throws SQLException;
	public Boolean removeMedicine(int id) throws SQLException;
}
