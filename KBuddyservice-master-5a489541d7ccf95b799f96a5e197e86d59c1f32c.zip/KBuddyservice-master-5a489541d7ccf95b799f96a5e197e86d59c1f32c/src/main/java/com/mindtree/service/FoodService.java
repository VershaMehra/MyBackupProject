package com.mindtree.service;

import java.sql.SQLException;
import java.util.List;


import com.mindtree.entity.Food;

public interface FoodService {
	public int addFood(Food food) throws SQLException;
	public List<Food> findAllFoodItems() throws SQLException;
	public Boolean updateFood(Food food) throws SQLException;
	public Boolean removeFood(int id) throws SQLException;
}
