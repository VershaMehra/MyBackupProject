package com.mindtree.service;

import java.sql.SQLException;
import java.util.List;


import com.mindtree.entity.Malls;

public interface MallsService {
	public int addMalls(Malls malls) throws SQLException;
	public List<Malls> findAllMallsItems() throws SQLException;
	public Boolean updateMalls(Malls malls) throws SQLException;
	public Boolean removeMalls(int id) throws SQLException;
}
