package com.mindtree.service;

import java.sql.SQLException;
import java.util.List;


import com.mindtree.entity.Visiting;

public interface VisitingService {
	public int addVisiting(Visiting visiting) throws SQLException;
	public List<Visiting> findAllVisitingItems() throws SQLException;
	public Boolean updateVisiting(Visiting visiting) throws SQLException;
	public Boolean removeVisiting(int id) throws SQLException;
}
