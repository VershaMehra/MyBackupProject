package com.mindtree.repository;

import java.util.List;

public interface GenericRepository<T, ID> {
	void insertEntity(T entity);
	List<T> getAllEntities(Class<T> clazz);
	List<T> getByQuery(String query, Object... queryParams);
	void updateEntity(T entity);
	void deleteEntity(T entity);
	
}
