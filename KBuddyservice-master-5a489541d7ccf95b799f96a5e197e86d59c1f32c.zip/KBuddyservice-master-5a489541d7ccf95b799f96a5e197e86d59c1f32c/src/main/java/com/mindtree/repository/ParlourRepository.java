package com.mindtree.repository;

import java.sql.SQLException;
import java.util.List;
import com.mindtree.entity.Parlour;

public interface ParlourRepository {
	public int addParlour(Parlour parlour) throws SQLException;
	public List<Parlour> findAllParlourItems() throws SQLException;
	public Boolean updateParlour(Parlour parlour) throws SQLException;
	public Boolean removeParlour(Parlour parlour) throws SQLException;
	
	
}
