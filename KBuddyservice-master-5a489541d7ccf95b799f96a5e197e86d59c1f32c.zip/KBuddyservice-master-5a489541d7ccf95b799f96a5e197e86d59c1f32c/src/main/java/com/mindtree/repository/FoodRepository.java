package com.mindtree.repository;

import java.sql.SQLException;
import java.util.List;
import com.mindtree.entity.Food;

public interface FoodRepository {
	public int addFood(Food food) throws SQLException;
	public List<Food> findAllFoodItems() throws SQLException;
	public Boolean updateFood(Food food) throws SQLException;
	public Boolean removeFood(Food food) throws SQLException;
	
	
}
