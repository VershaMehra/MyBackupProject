package com.mindtree.collection;

import java.util.ArrayList;
import java.util.HashMap;

public class Mapping {
public static void main(String[] args) {
	
	HashMap<String,ArrayList<String>> map=new HashMap<String,ArrayList<String>>();
	
	ArrayList<String> a=new ArrayList<String>();
	a.add("versha");
	a.add("abcd");
	
	ArrayList<String> b=new ArrayList<String>();
	b.add("mehra");
	b.add("wwww");
	
	map.put("aa", a);
	map.put("bb", b);
		
	System.out.println(map);
	}
}

