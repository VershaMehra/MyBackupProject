package com.mindtree.collection;

public class Multimap {

	public static void main(String[] args) {

		
		
	}

}
