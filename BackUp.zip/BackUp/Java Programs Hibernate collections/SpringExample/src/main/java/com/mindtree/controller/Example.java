package com.mindtree.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Example {
	
	 @RequestMapping(value = "/hello", method = RequestMethod.GET)
	 public String sayHello(Model model) {
	     model.addAttribute("message", "Hi");
	     model.addAttribute("author", "versha");
	     return "hello";
	   }

	 
	 @RequestMapping(value="/bye",method=RequestMethod.GET)
	 public String sayBye(Model model){
		 
		 return "bye";
	 }
}
