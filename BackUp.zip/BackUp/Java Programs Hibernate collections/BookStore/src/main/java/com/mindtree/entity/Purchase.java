package com.mindtree.entity;

import java.awt.print.Book;
import java.util.Date;

//@Entity
public class Purchase {
/*@Id
@GeneratedValue(strategy=GeneratedType=IDENTITY)*/
	private int purchaseId;
	private String customerName;
	private int customerMobileNo;
	private Date purchaseDate;
	private int amount;
	private Book book;
	
	
	
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerMobileNo() {
		return customerMobileNo;
	}
	public void setCustomerMobileNo(int customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	
	
	public Purchase(int purchaseId, String customerName, int customerMobileNo, Date purchaseDate, int amount,
			Book book) {
		super();
		this.purchaseId = purchaseId;
		this.customerName = customerName;
		this.customerMobileNo = customerMobileNo;
		this.purchaseDate = purchaseDate;
		this.amount = amount;
		this.book = book;
	}

	
	public Purchase() {
		super();
	}
	
	
	
	
	
	
	
	
}
