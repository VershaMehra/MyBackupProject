package com.mindtree.manager;

public class BookStoreSystemManager {

	
}
