package com.mindtree.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class BookStoreSystemClient {

	@RequestMapping(value = "/select", method = RequestMethod.GET)
	public String selectOptions(Model model, HttpServletRequest request, HttpServletResponse response) {

		/*
		 * String req1= request.getParameter("display"); String
		 * req2=request.getParameter("purchase"); String
		 * req3=request.getParameter("exit");
		 */
		if (request.getParameter("value") == "display") {

			return "DisplayBook";

		}

		else if (request.getParameter("value") == "purchase") {

			return "purchase";
		} else

			return "exit";

	}

	public static void main(String[] args) {

	}

}
