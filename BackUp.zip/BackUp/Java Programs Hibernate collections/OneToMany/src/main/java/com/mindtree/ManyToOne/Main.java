package com.mindtree.ManyToOne;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
	public static void main(String[] args) {
	
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		
		Employee e=new Employee();
		e.setEname("versha");
		e.setEmail("versha@gmail.cij");
		
		Employee e1=new Employee();
		e1.setEname("versha");
		e1.setEmail("versha@gmail.cij");
		
		Employee e2=new Employee();
		e2.setEname("versha");
		e2.setEmail("versha@gmail.cij");
		
		Employee e3=new Employee();
		e3.setEname("versha");
		e3.setEmail("versha@gmail.cij");
		
		Department d=new Department();
		d.setDname("IT");
		
		List<Employee> list1=new ArrayList<Employee>();
		list1.add(e);
		list1.add(e1);
		list1.add(e2);
		list1.add(e3);
		
		d.setList(list1);

		session.save(e);
		session.save(e1);
		session.save(e2);
		session.save(e3);
		session.save(d);
		t.commit();
		session.close();

		
		
}
	
	
}
