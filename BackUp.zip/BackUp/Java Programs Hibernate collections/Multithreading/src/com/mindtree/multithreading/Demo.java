package com.mindtree.multithreading;

public class Demo extends Thread {
	public void run(){
		
	
	}

}
