package practice;

public class MyThread implements Runnable 
{
	
	Atm atm;
	
public MyThread(Atm atm)
{
	this.atm=atm;
}

	
public void run()
{
	System.out.println(Thread.currentThread().getName()+" using Thread");
	atm.withDraw();
}
}
