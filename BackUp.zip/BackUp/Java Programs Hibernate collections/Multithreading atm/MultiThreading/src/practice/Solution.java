package practice;

public class Solution
{
public static void main(String[] args) 
{
	
	Atm atm=new Atm();
	//MyThread  t1=new MyThread(atm);
	//MyThread t2=new MyThread(atm);
	
	
	
	MyThread t1=new MyThread(atm);
	Thread thread1=new Thread(t1);
	
	MyThread t2=new MyThread(atm);
	Thread thread2=new Thread(t2);
	
	
	thread1.setName("Person 1");
	thread2.setName("Person 2");
	thread1.start();
	thread2.start();

	
	//System.out.println(Thread.currentThread().getPriority());
}
}
