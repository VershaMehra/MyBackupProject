package practice;

public class Atm
{
 
	int amount=500;
	synchronized public void withDraw()
	{
		amount =amount-100;
		System.out.println(amount);
	}
	
}
