package com.mindtree.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Controller
public class ExampleController {

	@RequestMapping(value="/welcome",method=RequestMethod.POST)
	   public String Welcome(Model model, HttpServletRequest request,HttpServletResponse response) {
	 
	String un=	request.getParameter("username");
		String pw=request.getParameter("password");
		if(un.equalsIgnoreCase("versha") && pw.equalsIgnoreCase("versha"))
		{
	     return "display";
	   }
		
		else
		{
			return "error";
		}
	
	}
}

