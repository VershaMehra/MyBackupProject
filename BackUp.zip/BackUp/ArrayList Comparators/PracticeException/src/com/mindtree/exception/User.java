package com.mindtree.exception;

public class User {
	
	public void check(String name) throws InvalidUserException {
		
		if(!name.contains("s")){
			throw new InvalidUserException("wrong name");
		}
		else
			System.out.println("right name");
		
	}

}
