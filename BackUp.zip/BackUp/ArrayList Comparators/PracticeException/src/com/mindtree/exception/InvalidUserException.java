package com.mindtree.exception;

public class InvalidUserException extends Exception {
	
	public InvalidUserException(String msg) {
		super(msg);
	}

}
