package com.mindtree.threading;

public class Atm {
	int amount=500;
	synchronized void withdraw(){
		

		System.out.println("before withdraw"+amount);
		amount =amount-100;
		System.out.println("after withdraw"+amount);
		
	}
	

}
