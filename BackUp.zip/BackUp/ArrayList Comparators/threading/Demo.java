package com.mindtree.threading;

public class Demo extends Thread {
	Atm atm;

	public Demo(Atm atm) {
		this.atm = atm;
	}

	public void run() {
		atm.withdraw();
	}

}
