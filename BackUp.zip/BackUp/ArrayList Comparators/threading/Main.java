package com.mindtree.threading;

public class Main {

	public static void main(String[] args) {

		Atm atm=new Atm();

		Demo t1=new Demo(atm);
		Demo t2=new Demo(atm);

		t1.start();
		t2.start();

		
		
	}

}
