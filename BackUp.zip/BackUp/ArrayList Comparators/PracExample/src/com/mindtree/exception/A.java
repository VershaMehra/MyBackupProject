package com.mindtree.exception;

public class A {
	public static void check() throws InvalidNameException{
	try{
		int n=3/0;
	}
	catch(Exception e){
		throw new InvalidNameException("check ur i/p",e);
	}
	}
}
