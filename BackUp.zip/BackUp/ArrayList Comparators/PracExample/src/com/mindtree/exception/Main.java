package com.mindtree.exception;

public class Main {
	public static void main(String[]args) {
		
		try {
			C.check2();
		} catch (InvalidNameException e) {
			System.out.println(e.getMessage()+" "+e.getCause());
		}
		
	}

}
