package com.mindtree.exception;

public class B {
 public static void check1() throws InvalidNameException{
	
	 A.check();
}
}