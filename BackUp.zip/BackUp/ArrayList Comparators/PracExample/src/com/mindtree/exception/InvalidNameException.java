package com.mindtree.exception;

public class InvalidNameException extends Exception {

	public InvalidNameException(String msg, Throwable cause) {
		
		super(msg,cause);
	}



	
}
