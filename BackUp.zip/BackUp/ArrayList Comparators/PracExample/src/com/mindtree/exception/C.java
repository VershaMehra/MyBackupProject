package com.mindtree.exception;

public class C {
	public static void check2() throws InvalidNameException{
		
		B.check1();
	}

}
