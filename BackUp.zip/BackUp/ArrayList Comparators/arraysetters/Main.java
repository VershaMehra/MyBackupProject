package com.mindtree.arraysetters;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {

		System.out.println("enter no of employees");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		Employee[] array = new Employee[n];

		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(in);
		for (int i = 0; i < n; i++) {
			
			System.out.println("enter mid");
			int mid = Integer.parseInt(br.readLine());
			//e.mid = mid;
			System.out.println("enter name");
			String name = br.readLine();
			//e.name = name;
			System.out.println("enter salary");
			int salary = Integer.parseInt(br.readLine());
			//e.salary = salary;
			Employee e = new Employee(mid,name,salary);
			
			
			array[i] = e;
		}

		for (int i = 0; i < n; i++) {

			System.out.println(array[i]);

		}

		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i].getName().compareTo(array[j].getName()) > -1) {
					Employee temp = array[i];
					array[i] = array[j];
					array[j] = temp;

				}
			}
		}
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}

	}

}
