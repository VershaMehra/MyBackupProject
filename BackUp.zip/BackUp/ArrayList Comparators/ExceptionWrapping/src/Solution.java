import java.util.Scanner;

public class Solution 
{
public static void main(String[] args) throws InvalidInputException {
	Scanner scan=new Scanner(System.in);
	try{
		System.out.println("enter a number");
	int n=scan.nextInt();
	System.out.println(n);
	}
	catch(Exception e)
	{
		throw new InvalidInputException("Check ur input",e);
	}
	}
}
