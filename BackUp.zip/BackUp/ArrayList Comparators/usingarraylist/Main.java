package com.mindtree.usingarraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import com.mindtree.arrayusingsetter.Employee;

public class Main {

	public static void main(String[] args) {

		ArrayList<Employee> list = new ArrayList<Employee>();

		System.out.println("enter no of employees");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		for (int i = 0; i < n; i++) {
			Employee e = new Employee();
			System.out.println("enter the mid");
			int mid = sc.nextInt();
			System.out.println("enter the name");
			String name = sc.next();
			System.out.println("enter the salary");
			int salary = sc.nextInt();

			e.setMid(mid);
			e.setName(name);
			e.setSalary(salary);

			list.add(e);

		}

		System.out.println(list);
		Collections.sort(list,new Demo());

	}

}
