package com.mindtree.comparator;

import java.util.Comparator;

public class Alpha implements Comparator<Cricket> {

	@Override
	public int compare(Cricket o1, Cricket o2) {

		if (o1.getScore() > o2.getScore())
			return 1;
		else
			return -1;
		
	}
	

}
