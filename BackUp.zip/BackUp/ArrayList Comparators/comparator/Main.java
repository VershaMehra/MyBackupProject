package com.mindtree.comparator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

public class Main {
public static void main(String[] args) throws IOException {
	
	
	
	ArrayList<Cricket> al=new ArrayList<Cricket>();
	InputStreamReader in=new InputStreamReader(System.in);
	BufferedReader br=new BufferedReader(in);
	System.out.println("enter the number of cricketers");
	int n=Integer.parseInt(br.readLine());
	
	for(int i=0;i<n;i++)
	{
		Cricket cr=new Cricket();
		System.out.println("enter name");
	String name=br.readLine();
	System.out.println(name);
	cr.setName(name);
	System.out.println("enter age");
	int age=Integer.parseInt(br.readLine());
	System.out.println(age);
	cr.setAge(age);
	System.out.println("enter score");
	int score=Integer.parseInt(br.readLine());
	System.out.println(score);
	cr.setScore(score);
	
	al.add(cr);
	System.out.println(al);
	
	}
	
	System.out.println(al);
	Collections.sort(al,new Alpha());
	System.out.println(al);
	
	
}
	
	
}
