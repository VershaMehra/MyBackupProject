package com.mindtree.ArrayList;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

public class InputNumbers {
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		
		InputStreamReader in=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(in);
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		int n;
		
		/*for(int i=1;i<10;i++)
		{
			System.out.println("enter the number");
			
			int n=Integer.parseInt(br.readLine());
			if(n==-1)
			{
				list.add(n);
				break;
			}
			list.add(n);
		}*/
		do{
			System.out.println("enter the number");
			 n=Integer.parseInt(br.readLine());
			list.add(n);
		}
		while(n!=-1);
		
		System.out.println(list);
		//Collections.sort(list);
		
		
		for(int i=0;i<list.size();i++)
		{
			for(int j=i+1;j<list.size();j++)
			{
				if(list.get(i)==list.get(j))
				{
					list.remove(j);
				}
			}
		}
		
	
		for(int i=0;i<list.size();i++)
		{
			for(int j=i+1;j<list.size();j++)
			{
				if(list.get(i)>list.get(j))
				{
					int temp=list.get(i);
					list.set(i,list.get(j));
					list.set(j,temp);
					
				}
			}
		}
		
		
		System.out.println(list);
	}
	
	

}
