package com.mindtree.SpringServiceImpl;

import com.mindtree.Exceptions.InvalidUserException;
import com.mindtree.SpringDaoImpl.ExampleDaoImpl;

public class ExampleServiceImpl {

	ExampleDaoImpl dao=new ExampleDaoImpl();
	
	
	public boolean validate(String username,String password)
	{
		
		try{
			return dao.validate(username,password);
		}
		
		catch(InvalidUserException iue)
		{
			System.out.println(iue.getMessage());
			return false;
		}
		
		
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
		}
	
	
	}
}
