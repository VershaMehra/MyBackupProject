package com.mindtree.SpringController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.SpringServiceImpl.ExampleServiceImpl;

@Controller
public class ExampleController {
	
	ExampleServiceImpl service=new ExampleServiceImpl();
	
	@RequestMapping(value="/welcome",method=RequestMethod.POST)
	public String WelcomeWorld(Model model,HttpServletRequest req,HttpServletResponse res)
	{
		String username=req.getParameter("username");
		String password=req.getParameter("password");
		boolean flag=service.validate(username,password);	
		
		model.addAttribute("username",username);
		
		if(flag==true)
		{
			return "welcome";
		}
		else
		{
			return "error";
		}
	}

}
