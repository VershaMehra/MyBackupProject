package com.mindtree.Exceptions;

public class InvalidUserException extends Exception
{
	public InvalidUserException(String msg)
	{
		super(msg);
	}

}
