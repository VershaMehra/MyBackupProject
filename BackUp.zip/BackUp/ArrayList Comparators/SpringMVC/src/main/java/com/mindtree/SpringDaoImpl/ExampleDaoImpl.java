package com.mindtree.SpringDaoImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mindtree.Exceptions.InvalidUserException;

public class ExampleDaoImpl 
{
	Connection con;
	
	public ExampleDaoImpl()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","Welcome123");
		} catch (Exception e) {
			e.printStackTrace();
		}
 
	}
	
	public boolean validate(String username,String password) throws InvalidUserException, SQLException 
	{
		int uid=0;
		ResultSet rs;
		
		
			Statement st=con.createStatement();
			String sql="select uid from users where uname='"+username+"' and password='"+password+"';";
			rs = st.executeQuery(sql);
			if(rs.next())
				uid=rs.getInt(1);
		
		
			if(uid>0)
			return true;
		else
			//return false;
			throw new InvalidUserException("wrong input");
		
		
	}
}
