package com.mindtree.arrayusingsetter;

public class Employee {

	int mid;
	String name;
	int salary;
	
	
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return "Employee [mid=" + mid + ", name=" + name + ", salary=" + salary + "]";
	}
	
	
	
	
}
