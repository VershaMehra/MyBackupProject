package com.mindtree.arrayusingsetter;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		System.out.println("enter no of employees");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		Employee[] array = new Employee[n];

		for (int i = 0; i < n; i++) {
			Employee e = new Employee();
			System.out.println("enter the mid");
			int mid = sc.nextInt();
			System.out.println("enter the name");
			String name = sc.next();
			System.out.println("enter the salary");
			int salary = sc.nextInt();

			e.setMid(mid);
			e.setName(name);
			e.setSalary(salary);

			array[i] = e;

		}

		for (int i = 0; i < n; i++) {

			System.out.println(array[i]);
		}

	}
}