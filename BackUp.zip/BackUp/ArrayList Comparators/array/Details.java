package com.mindtree.array;

import java.util.Collections;
import java.util.Scanner;

public class Details {
	public static void main(String[] args) {
		


		EmployeeDetails[] array = new EmployeeDetails[3];

		for (int a = 0; a < 3; a++) {
			
			EmployeeDetails ed1 = new EmployeeDetails();
			Scanner sc = new Scanner(System.in);

			System.out.println("enter mid");
			ed1.mid = sc.nextInt();
			
			System.out.println("enter salary");
			ed1.salary = sc.nextInt();
			System.out.println("enter name");
			ed1.name = sc.next();
			array[a] = ed1;
		}


		for(int n=0;n<3;n++)
		{
			System.out.println(array[n]);
		}
		
		int temp;
		
		
		/*for(int i=0;i<array.length;i++)
		{
			for(int j=1;j<3-i;j++){
				if(array[j-1]>array[j])
				{
					 temp = array[j-1];  
                     array[j-1] = array[j];  
                     array[j] = temp;  
				}
				
			}
			
		}*/
		
		
	}
}
