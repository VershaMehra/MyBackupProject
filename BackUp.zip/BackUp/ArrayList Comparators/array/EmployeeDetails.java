package com.mindtree.array;

public class EmployeeDetails {
	
	int mid;
	String name;
	int salary;
	@Override
	public String toString() {
		return "EmployeeDetails [mid=" + mid + ", name=" + name + ", salary=" + salary + "]";
	}
	
	

	
	
	
}
