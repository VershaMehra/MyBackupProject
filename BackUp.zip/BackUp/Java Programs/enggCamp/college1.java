package enggCamp;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class college1 {

	public static void main(String[] args) {
		System.out.println("enter no of students");
		int n=Integer.parseInt(args[0]);
System.out.println(args[0]);
int id=0;
LinkedHashSet<Integer> hs = new LinkedHashSet<Integer>();
Scanner sc=new Scanner(System.in);
System.out.println("enter ids");


	while(hs.size()!=n)
	{
		id=sc.nextInt();
		hs.add(id);
	}
	System.out.println(hs);




String[] name = new String[n];
Scanner sc1=new Scanner(System.in);
System.out.println("enter names");
int j=0;
for(j=0;j<n;j++)
{
	name[j]=sc1.nextLine();
  
	
}
for(j=0;j<n;j++)
{
	System.out.println(name[j]);
}



HashMap<Integer,String> hm = new HashMap<Integer,String>();

int b=0;

for(int x:hs )
{
	hm.put(x,name[b]);
	b++;
}
	System.out.println(hm);
	
	
	
	
	
	Scanner sc2=new Scanner(System.in);
	System.out.println("enter the marks");
	int[] marks=new int[5];
	int a=0;
	for(a=0;a<n;a++)
	{
		marks[a]=sc2.nextInt();
	}
	for(a=0;a<n;a++)
	{
		System.out.println(marks[a]);
	}
	
	
	int w=0;
	Map<Integer,Integer> hm1 = new HashMap<Integer,Integer>();
	for(int k:hs)
	{
		hm1.put(k,marks[w]);
		w++;
	}
		System.out.println(hm1);
	

	Set<Integer> keys=hm.keySet();
	System.out.println("data of the students");
	for(int value:keys)
	{
		System.out.println(value+""+hm.get(value)+""+hm1.get(value));
	}
	
	
	}
}


