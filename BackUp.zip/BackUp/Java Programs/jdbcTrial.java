import java.sql.*;

public class jdbcTrial {
	public static void main(String[]args) throws SQLException, ClassNotFoundException {
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "Welcome123");
	 
		 Statement stmt = conn.createStatement();
	      
	      String query = "CREATE TABLE employee1 " +
	                   "(id INTEGER not NULL, " +
	                   " first VARCHAR(50), " + 
	                   " last VARCHAR(50), " + 
	                   " age INTEGER, " + 
	                   " PRIMARY KEY ( id ))"; 
	      stmt.executeUpdate(query);
	      System.out.println("table created");
	      
	      String query1="insert into students values(?,?,?,?)";
	      PreparedStatement preparedStmt = conn.prepareStatement(query);
	      preparedStmt.setInt(1, 101);
	      preparedStmt.setString(2, "versha");
	      preparedStmt.setString(3, "mehra");
	      preparedStmt.setInt(4, 22);
	      stmt.executeUpdate(query1);
	      
	    
	      conn.close();
	      stmt.close();
	      
	}
}
