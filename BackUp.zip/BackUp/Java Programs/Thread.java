
 class Example extends Thread {
     
     
	
}
