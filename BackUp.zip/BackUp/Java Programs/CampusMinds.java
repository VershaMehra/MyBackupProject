
public class CampusMinds {

	int mid;
	String name;
	
	 public String toString() { 
		 return "";
	 }
}
