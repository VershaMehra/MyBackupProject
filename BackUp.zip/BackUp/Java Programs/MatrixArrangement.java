import java.util.ArrayList;
import java.util.Collections;

public class MatrixArrangement {

	public static void main(String[] args) {
		
		int a1[][]={{4,2,13},{3,8,5},{9,6,17}};
		int b1[][]={{4,1,3},{3,8,5},{4,16,17}};
		int[]result=arrangeElements(a1);
		
		System.out.println("output 1");
		
		for(int x:result)
			System.out.println(x);
		
		int[]result1=arrangeElements(b1);
		System.out.println("output 2");
		for(int x:result1)
			System.out.println(x);
		
	}

	
	public static int[] arrangeElements(int[][] inputArray){
		
		ArrayList<Integer> arr = new ArrayList<Integer>();
		int result[];
		for(int i=0;i<inputArray.length;i++)
		{
			for(int j=0;j<inputArray[i].length;j++)
			{
				arr.add(inputArray[i][j]);
			}
		}
		
		int length=arr.size();
		Collections.sort(arr);
		result=new int[length];
		int m=length-1;;
		
		for(int i=0,j=length-1;i<=j;j--,i++)
		{
			if(m>=0)
				result[i]=arr.get(m--);
			if(m>=0)
				result[j]=arr.get(m--);
			}
		
		
		return result;
		
	}
	
}
