package exception;

import java.util.Scanner;

public class ExceptionMain {

	public static void main(String[] args) {
		try{
			System.out.println("enter marks");
		Scanner sc=new Scanner(System.in);
		int marks=sc.nextInt();
		Exceptions.employee(marks);
		
		}
		catch (InvalidException e1) {
			System.out.println(e1.getMessage());
			}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
