package exception;

public class Exceptions {

	static void employee(int marks) throws InvalidException {

		if (marks > 100) {
			throw new InvalidException("Invalid Exception");
		}
	}
}


