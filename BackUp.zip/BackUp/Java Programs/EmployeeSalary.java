import java.security.KeyStore.Entry;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import employee.employee;

public class EmployeeSalary {

	public static void main(String[] args) {
		try{
		
		Scanner sc = new Scanner(System.in);
		HashMap<Integer, Integer> hm = new HashMap<>();
		
		System.out.println("Enter no of input");
		int n = sc.nextInt();
		
		for (int i = 0; i < n; i++) {
			System.out.println("Enter id");
			int id = sc.nextInt();
			
			System.out.println("Enter marks");
			int marks = sc.nextInt();
			
			EmployeeException.employee(marks);   //exception handling
			
			hm.put(id, marks);
		}
		for (Map.Entry<Integer, Integer> p : hm.entrySet()) {
				System.out.println("ID: " + p.getKey() + "\tMarks:" + p.getValue());
		}
		//System.out.println(hm);
		}
		
		
		catch (InvalidException1 e1) {
			e1.printStackTrace();
			}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}








