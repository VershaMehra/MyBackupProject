package practiceException;

import java.util.Scanner;

public class Main {
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
		boolean flag;
		do{
	try{
		
		System.out.println("enter a number");
	int number=sc.nextInt();
	Demo ob=new Demo();
	ob.check(number);
	flag=false;
	}
	catch(Exception e)
	{
		System.out.println(e.getMessage());
		flag=true;
	}
		}while(flag);
}
}