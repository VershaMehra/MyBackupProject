package practiceException;

public class NegativeException extends Exception{
	public NegativeException(String msg)
	{
		super(msg);
	}

}
