package practiceException;

public class Demo {
	public void check(int number) throws ZeroException,NegativeException{
		
		if(number==0) 
		{
			throw new ZeroException("zero number"); 
		}
		else if(number<0)
		{
			throw new NegativeException("negative number");
		}
		else
			System.out.println("positive number");
		
		
	}
}
