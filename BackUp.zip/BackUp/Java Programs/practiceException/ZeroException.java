package practiceException;

public class ZeroException extends Exception{
	public ZeroException(String msg)
	{
		super(msg);
	}

}
