package threadingQuestion;

import java.util.Scanner;

public class Solution 
{
	static  int count=0;
	static int y=0;
public static void main(String args[])
{
	Scanner scan=new Scanner(System.in);
	System.out.println("enter no of Threads");
	int x=scan.nextInt();
	System.out.println("enter no of times to inc count");
	y=scan.nextInt();
	Demo d[]=new Demo[x];	//creation of thread
	
	for(int i=0;i<x;i++)
	{
		d[i]=new Demo();
		d[i].start();
	}
	
	for(int i=0;i<x;i++)
		try {
			d[i].join();
	     	} 
	    catch (InterruptedException e)
			{
			e.printStackTrace();
		    }
	System.out.println("Actual count is "+(x*y));
	System.out.println("Thread count is "+Demo.getCount());
}


public static class Demo extends Thread
{
	 public void run()
	{
		 inc();
	 }
	 public static synchronized void inc()	//one resource is shared by one thread at a time
	 {
		 for(int i=0;i<y;i++)
			{
				count=count+1;
			}
	 }
	
	public static int getCount()
	{
		return count;
	}
}


}
