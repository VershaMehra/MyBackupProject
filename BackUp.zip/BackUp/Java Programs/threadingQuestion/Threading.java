package threadingQuestion;

import java.util.Scanner;



public class Threading {

	static  int count=0;
	static int y=0;
public static void main(String args[])
{
	Scanner scan=new Scanner(System.in);
	System.out.println("enter no of Threads");
	int x=scan.nextInt();
	System.out.println("enter no of times to inc count");
	y=scan.nextInt();
	Thread t[]=new Thread[x];
	for(int i=0;i<x;i++)
		t[i]=new Thread(new Demo());
	for(int i=0;i<x;i++)
		t[i].start();
	for(int i=0;i<x;i++)

		try {
			t[i].join();
		}
	    catch (InterruptedException e) {
			e.printStackTrace();
		}
	System.out.println("Actual count is "+(x*y));
	System.out.println("Thread count is "+Demo.getCount());
}


public static class Demo implements Runnable
{
	 public void run()
	{
		 inc();
	 }
	 public static synchronized void inc()
	 {
		 for(int i=0;i<y;i++)
			{
				count=count+1;
			}
	 }
	
	public static int getCount()
	{
		return count;
	}
}

	
	
	
}
