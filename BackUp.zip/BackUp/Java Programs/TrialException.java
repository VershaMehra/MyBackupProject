
public class TrialException {

	
		 public static void trial(Integer number)throws InvalidException {
		   
			
			if(number>100)
			{
				throw new InvalidException();
			}     
				   
				   
			   }  
			     
	}



	class InvalidException extends Exception{
		
		InvalidException()
		{
			super("number is greater than 100");
		}
	}
	

