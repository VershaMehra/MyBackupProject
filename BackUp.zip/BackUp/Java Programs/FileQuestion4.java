import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileQuestion4 {

	public static void main(String[] args) throws FileNotFoundException {
	
		File text = new File("products.txt");
		
		System.out.println("enter the category");
		Scanner sc1=new Scanner(System.in);
		String str=sc1.nextLine();
		
		
		Scanner sc = new Scanner(text);
		 int lineNumber = 1;
		
		 
		 
		 while(sc.hasNextLine()){
	            String line = sc.nextLine();
	            //System.out.println(line);
	            String[]words=line.split(",");
	            	if((words[3].trim()).equalsIgnoreCase(str))
	            			{
	            				System.out.println(line);
	            			}
	}
		 
		 
		 
}
}
