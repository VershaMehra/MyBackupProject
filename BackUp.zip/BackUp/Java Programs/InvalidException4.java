
public class InvalidException4 {

}
