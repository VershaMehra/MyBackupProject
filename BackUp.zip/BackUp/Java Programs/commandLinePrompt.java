
public class commandLinePrompt {

	public static void main(String[] args) {
		double d=Double.parseDouble(args[0]);
		int a;
		 a=(int) d;
		double c=d-a;
		System.out.println(c);
		if(c!=0)
			System.out.println("invalid");


	}

}
