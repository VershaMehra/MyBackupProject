package NoException;

public class IntegerException extends Exception{

	public String getMessage()
	{
		return "This is not a  number";
	}
	
}
