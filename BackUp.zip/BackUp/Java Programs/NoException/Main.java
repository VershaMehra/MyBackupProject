package NoException;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		
		try{
			int n=sc.nextInt();
		System.out.println("entered number is "+n);
		}
		
		catch(InputMismatchException e)
		{
			IntegerException ie=new IntegerException();
			System.out.println(ie.getMessage());
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
	}

}
