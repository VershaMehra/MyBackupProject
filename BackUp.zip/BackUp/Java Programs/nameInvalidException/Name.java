package nameInvalidException;

public class Name {
	public void check(String name) throws NameInvalidException{
		
		if(name.equalsIgnoreCase("versha"))
			System.out.println("Good Girl");
		else
			throw new NameInvalidException("Wrong Name");
	}
}
