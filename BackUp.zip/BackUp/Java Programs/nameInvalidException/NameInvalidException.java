package nameInvalidException;

public class NameInvalidException extends Exception {
	public NameInvalidException(String msg){
		super(msg);
	}

}
