package nameInvalidException;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter your name");
		String name = sc.nextLine();

		try {
			Name ob = new Name();
			ob.check(name);
			}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}