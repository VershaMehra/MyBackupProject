
public class Demo {
	public static void main(String args[]) {
		App a = new App();
		App b = new App();
		a.setName("add");
		b.setName("print");
		a.start();
		b.start();
	}
}
