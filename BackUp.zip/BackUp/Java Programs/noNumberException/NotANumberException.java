package noNumberException;

public class NotANumberException extends Exception {
	public NotANumberException(String msg){
		super(msg);
	}

}
