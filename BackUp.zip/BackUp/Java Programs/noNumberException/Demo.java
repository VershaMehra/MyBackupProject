package noNumberException;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Demo {
	public static void main(String[]args) throws NotANumberException{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		try{
			int n=sc.nextInt();

		}
		catch(InputMismatchException e)
		{
			throw new NotANumberException("Check iNput Datatype");
		}
		
	}
	

}
