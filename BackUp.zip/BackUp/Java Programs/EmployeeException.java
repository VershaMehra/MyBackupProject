public class EmployeeException {
	 static void employee(Integer marks)throws InvalidException1 {
		 
		 if(marks>100)
		 {
			 throw  new InvalidException1();
		 }
	 }
}
	 class InvalidException1 extends Exception{
			InvalidException1()
			{
				super("more than maximum marks");
			}
		}






