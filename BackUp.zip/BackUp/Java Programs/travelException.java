
public class travelException {
	 public static void travel(String destination){//throws InvalidException {
	   
		 String s="mysore";
		if(destination.equals(s)){
			
		}
		//	throw new InvalidException();
	 }
		     
}


