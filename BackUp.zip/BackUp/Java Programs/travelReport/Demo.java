package travelReport;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {

		Connection con;
		public Demo()
		{
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/travel","root","Welcome123");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		public void getDetails(String dest) throws InvalidDestinationNameException, SQLException
		{
			char c[]=dest.toCharArray();
			int spacecount=0;
			for(int i=0;i<c.length;i++)
			{
				if(!((c[i]>=65 && c[i]<=90)||(c[i]>=97 && c[i]<=122)|| c[i]==32))
				{
					throw new InvalidDestinationNameException("enter valid destination");
				}
				if(c[i]==32)
					spacecount++;
			}
			if(spacecount==dest.length())
				throw new InvalidDestinationNameException("enter valid destination");

			String sql="select bookingid,source from travelbooking where destination='"+dest+"'";
			Statement statement=con.createStatement();
			ResultSet rs=statement.executeQuery(sql);
			if(rs.wasNull())
				System.out.println("No data found");
			else
			{
				System.out.println("BookingID\tSource");
				while(rs.next())
				{
					System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2));
				}
			}
		}
		
	}


