package travelReport;

import java.util.Scanner;

public class Solution {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("enter a destination");
		String dest=scan.next();
		
		try
		{
			Demo d =new Demo();
			d.getDetails(dest);
		}
		catch(InvalidDestinationNameException e)
		{
			System.out.println(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	}

