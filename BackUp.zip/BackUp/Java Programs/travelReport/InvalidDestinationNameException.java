package travelReport;

public class InvalidDestinationNameException extends Exception{

		public InvalidDestinationNameException(String msg)
		{
			super(msg);
		}
	}

	

