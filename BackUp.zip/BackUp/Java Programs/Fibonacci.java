
public class Fibonacci {

	public static void main(String[] args) {

		Fibonacci obj = new Fibonacci();
		System.out.println(obj.fibonacci(6));
		System.out.println(obj.fibonacci(10));

	}

	int fibonacci(int x) {
		
		if (x == 0)
			return 0;
		else if (x == 1)
			return 1;
		else if (x == 2)
			return 1;
		else
			return (fibonacci(x - 1) + fibonacci(x - 2));
	}

}
