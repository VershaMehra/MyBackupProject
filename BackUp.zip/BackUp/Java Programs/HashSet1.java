import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class HashSet1 {
	public static void main(String[] args){
		
		
		
   HashSet<Integer> hs=new HashSet<Integer>();
  HashSet<Integer> hs1 = new HashSet<Integer>();
   HashSet<Integer> hs2=new HashSet<Integer>();
   hs.add(90);
   hs.add(100);
   hs.add(30);
   hs1.add(90);
   hs1.add(40);
   hs1.add(50);
   hs2.add(30);
   hs2.add(70);
   hs2.add(9);/*
   System.out.println(hs1);
   ArrayList<String> al=new ArrayList<String>();
   al.add("hsjs");
   al.add("ytyt");
   al.add("ijij");
   System.out.println(al);
   boolean b1,b2,b3;
   b1=hs.add(95);*/
	
		HashMap<String,HashSet<Integer>> map = new HashMap<String,HashSet<Integer>>();
map.put("a",hs1);
map.put("b",hs2);	
map.put("c",hs);	


		System.out.println(map);
		
}
}