package stringSession;

public class recursion {
	
	
	public static void function1(int a){
	if(a==101)
		return;
	System.out.print(a+"\t");
	function1(a+1);
}
	public static void main(String[]args){
		
	/*	for(int i=1;i<=100;i++)
	{
		System.out.print(i+"\t");
		}
	}*/
		function1(1);

}
}
		
		
		
		
