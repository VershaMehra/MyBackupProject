package stringSession;

import java.util.Scanner;

public class selectionSort {
	public static void main(String[]args){
		
		int[]arr={7,2,6,1,9,5};
		int[]res=new int[arr.length];
		for(int i=0;i<arr.length-1;i++)
		{
			int min=arr[i];
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i]>arr[j]&&j>i)
				{
					
					if(min>arr[j])
					min=arr[j];
				}
			}
			res[i]=min;
		}
		for(int i=0;i<res.length;i++)
		{
			System.out.println(res[i]);
		}
		
		
		
	}

	}
