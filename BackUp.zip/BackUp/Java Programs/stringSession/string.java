package stringSession;

public class string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//String s="welcome to java";
/*String s=new String("versha"); 
System.out.println(s);*/
char[]a={'a','b','c',65};
//System.out.println(a[4]);

/*String s=new String(a);
System.out.println(s);*/
/*String s1="welcome to java";
char[]ch={'k','a'};
String s2=new String(ch);
String s3=new String("welcome");
System.out.println(s1);
System.out.println(s2);
System.out.println(s3);*/


/*String s="mindtree";
s=s.concat("kalinga");
System.out.println(s);*/

/*String s1="mindtree";
String s2="mindtree";
String s3=new String("mindtree");
String s4="mindtree";
System.out.println(s1.equals(s2));//true
System.out.println(s1.equals(s3));//true
System.out.println(s1.equals(s4));//false

System.out.println(s1==s2);//true
System.out.println(s1==s3);//false
System.out.println(s1==s4);//false
*/
/*String s1="ABC";
String s2="ABC";
String s3="c";
System.out.println(s1.compareTo(s2));
System.out.println(s1.compareTo(s3));
System.out.println(s3.compareTo(s1));*/

/*String s=30+20+"Shuvam"+40+40;
System.out.println(s);
*/


StringBuffer sb=new StringBuffer("hello");
long starttime=System.currentTimeMillis();
for(int i=0;i<=100;i++)
	
sb.append("vivek");
System.out.println(sb);

long estimatedtime=System.currentTimeMillis()-starttime;
System.out.println();
System.out.println(estimatedtime);






	}

}
