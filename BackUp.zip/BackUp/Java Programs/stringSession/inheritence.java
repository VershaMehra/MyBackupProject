package stringSession;

class best
{
	int bal=1000;
}

public class inheritence {
	
	public inheritance()
	{
		System.out.println("test");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
new test();
System.out.println(newbest);
	}

}
