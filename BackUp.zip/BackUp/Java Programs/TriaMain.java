
public class TriaMain {

	public static void main(String[] args) {
	
		TrialProject ob=new TrialProject();
		ob.abc();
	}

}
