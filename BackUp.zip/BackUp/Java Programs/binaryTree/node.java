package binaryTree;

public class node {
	
	int value;
	node left,right;
	public node(int n)
	{
		value=n;
		left=null;
		right=null;
	}
	

}
