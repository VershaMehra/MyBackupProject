package binaryTree;

public class binaryTree {

	node root;
	binaryTree(int p)
	{
		root=new node(p);
	}
	binaryTree()
	{
		root=null;
	}
	
	
	public static void printPostOrder(node nd)
	{
		if(nd==null)
		{
			return;
		}
		
		
			
			
			printPostOrder(nd.left);
			printPostOrder(nd.right);
			System.out.println(nd.value);		
	}
	
	
	public static void main(String[] args) {
		
binaryTree tree=new binaryTree();
tree.root=new node(13);
tree.root.left=new node(2);
tree.root.right=new node(1);
tree.root.left.left=new node(4);
tree.root.left.right=new node(5);
tree.root.left.left.left=new node(6);
tree.root.right.right=new node(3);

System.out.println(tree.root.left.left.value);
	
	printPostOrder(tree.root);
	
	}

}
