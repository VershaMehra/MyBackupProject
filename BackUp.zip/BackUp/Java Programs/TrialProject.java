
public class TrialProject {
	void abc() {
		try {
			def();
		} catch (ArithmeticException e) {
			System.out.println("Handled in abc");
		}
	}

	void def() throws ArithmeticException {
		System.out.println("def");
		
			ghi();
		
	}

	void ghi() throws ArithmeticException {
		int a = 4;
		int b = 0;

		System.out.println(a / b);

	}
}
