import java.util.ArrayList;

public class printConsecutiveCharacters {
	public static void main(String[] args) {
		String s1 = "I saw a CD play-er and a modem in ccd";
		String s2 = "Student List do not exist in sys-tem";
		System.out.println("First Input");
		consecutiveCharacters(s1);
		System.out.println("Second Input");
		consecutiveCharacters(s2);

	}

	public static void consecutiveCharacters(String input) {
		String str = input.toUpperCase();
		char a[] = str.toCharArray();
		ArrayList<String> alphabet = new ArrayList<String>();
		ArrayList<Integer> freq = new ArrayList<Integer>();

		for (int j = 1; j < a.length; j++)
		{
			if (a[j] - a[j - 1] == 1)
			{
				
				String m = "" + a[j - 1] + a[j];
				if (alphabet.contains(m))
				{
					int l = alphabet.indexOf(m); //getting index
					int p = freq.get(l) + 1; // incrementing corresponding freq by one
					freq.set(l,p); // updating new freq 

				}
				else // if not contains
				{
					alphabet.add(m);
					freq.add(1);
				}
				
			}
		}
		
		System.out.println(alphabet);
		System.out.println(freq);
	}
}
