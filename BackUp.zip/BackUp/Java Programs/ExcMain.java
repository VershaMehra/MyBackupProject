
public class ExcMain {

	public static void main(String[] args) {
try {
	throw new CustomVershaException();
} catch (CustomVershaException e) {
	e.printStackTrace();
}
	}

}
