import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.*;

public class generalTravelReport {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "Welcome123");

			Statement stmt = conn.createStatement();

			/*
			 * String query =
			 * "CREATE TABLE travelbooking (bookingid INTEGER not NULL,  source VARCHAR(50),destination VARCHAR(50), vehicletype VARCHAR(10),phoneno int, PRIMARY KEY ( bookingid ))"
			 * ; stmt.executeUpdate(query); System.out.println("table created");
			 */
			/*
			 * String query1 = "insert into travelbooking values(?,?,?,?,?)";
			 * PreparedStatement preparedStmt = conn.prepareStatement(query1);
			 * 
			 * 
			 * preparedStmt.setInt(1, 5001);
			 *  preparedStmt.setString(2, "mysore");
			 *  preparedStmt.setString(3, "bangalore");
			 * preparedStmt.setString(4, "L");
			 *  preparedStmt.setInt(5, 9740);
			 * System.out.println(preparedStmt.executeUpdate());
			 * 
			 * preparedStmt.setInt(1, 5002); preparedStmt.setString(2,
			 * "hyderabad"); preparedStmt.setString(3, "bangalore");
			 * preparedStmt.setString(4, "S"); preparedStmt.setInt(5, 934000);
			 * System.out.println(preparedStmt.executeUpdate());
			 * 
			 * preparedStmt.setInt(1, 5003); preparedStmt.setString(2,
			 * "vijaywada"); preparedStmt.setString(3, "hyderabad");
			 * preparedStmt.setString(4, "L"); preparedStmt.setInt(5, 92000);
			 * System.out.println(preparedStmt.executeUpdate());
			 */


			
Scanner sc3=new Scanner(System.in);
boolean des;
String destination;
do{
	des=false;
	System.out.println("enter the destination name");
	destination=sc3.next();
if(destination.equals("null"))
	des=true;
}while(des);

travelException.travel(destination);

String query2 = "select bookingid,source from travelbooking where destination='"+destination+"'";
			
			ResultSet rs = stmt.executeQuery(query2);
			while (rs.next()) {
				
				int bookingid = rs.getInt("bookingid");
				String source = rs.getString("source");
				
				System.out.print("BookingID: " + bookingid);
				System.out.print("source: " + source);
				System.out.println();
			}

			rs.close();
			conn.close();
		}
		
		catch (SQLException se) {
			se.printStackTrace();

		} 

		catch (Exception e) {
			e.printStackTrace();

		}
	}
}
