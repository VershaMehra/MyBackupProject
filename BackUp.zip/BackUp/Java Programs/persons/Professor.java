package persons;

public class Professor extends Person {

int bookPub;
	
	public Professor()
	{
	}

	public Professor(String name,int bookPub)
	{
		this.bookPub=bookPub;
	}
	
	public void display()
	{
		System.out.println("Professor Deatils:");
		System.out.println("Name : "+name);
		System.out.println("Books Published : "+bookPub);
	}
	
	
	@Override
	public boolean oustanding() {
		if(bookPub>4)
			return true;
		else
			return false;
	}
	
	
	
}
