package persons;

import java.util.Scanner;

public class Solution {

	
public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Person[] p = new Person[5];
		for(int i=0;i<5;i++)
		{
			System.out.println("Which details you want to enter?(Student/Professor)");
			String s = sc.next();
			if(s.equals("Student"))
			{
				System.out.println("Enter Student Name :");
				String sname = sc.next();
				System.out.println("Enter Student Percentage :");
				Double per = sc.nextDouble();
				p[i] = new Student(sname,per);
			}
			else if(s.equals("Professor"))
			{
				System.out.println("Enter Professor Name :");
				String pname = sc.next();
				System.out.println("Enter number of books published :");
				int book = sc.nextInt();
				p[i] = new Professor(pname,book);
			}
			else
			{
				System.out.println("Please enter either Professor/Student");
				i=i-1;
			}
		}
		
		
		
		System.out.println("enter details you want to print?(Student/Professor)");
		String sp = sc.next();
		if(sp.equals("Student"))
		{
			for(int i=0;i<5;i++)
			{
				if(p[i] instanceof Student)
				{
					if(p[i].oustanding())
					{
						((Student)p[i]).display();
					}
				}
			}
		}
		
		
		if(sp.equals("Professor"))
		{
			for(int i=0;i<5;i++)
			{
				if(p[i] instanceof Professor)
				{
					if(p[i].oustanding())
					{
						((Professor)p[i]).display();
					}
				}
			}
		}
			sc.close();
			
	}
	
	
	
}
