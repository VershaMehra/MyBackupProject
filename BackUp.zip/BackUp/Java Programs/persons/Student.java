package persons;

public class Student extends Person{

double percent;
	
	public Student()
	{
		percent=0;
	}

	public Student(String name,double percent)
	{
		super(name);
		this.percent=percent;
	}
	
	public void display()
	{
		System.out.println("Student Deatils:");
		System.out.println("Name : "+name);
		System.out.println("Books Published : "+percent);
	}
	
	
	@Override
	public boolean oustanding() {
		if(percent>=85)
			return true;
		else
			return false;
	}
	
	
	
}
