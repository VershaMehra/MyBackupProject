 package TryAnException;

import java.util.Scanner;

public class main {

	public static void main(String[] args) throws InvalidException {
		
		Scanner scan=new Scanner(System.in);
		try{
		System.out.println("enter x value");
		String s=scan.next();
		int x=validate(s);
		System.out.println("enter y value");
		s=scan.next();
		int y=validate(s);
		
		if(y==0)
		{
			throw new InvalidException();
		}
		else
			System.out.println(x/y);
		}
		
		
		catch(InvalidException ie)
		{
			System.out.println(ie.getMessage());
		}
		catch(NotIntegerException nie)
		{
			System.out.println(nie.getMessage());
		}
		catch(Exception e)
		{
		e.printStackTrace();	
		}
	}
	
	 
	
	public static int validate(String s) throws NotIntegerException {
		try{
			return Integer.parseInt(s);
		}
		catch(NumberFormatException e)
		{
			throw new NotIntegerException();
		}
	}
		}


