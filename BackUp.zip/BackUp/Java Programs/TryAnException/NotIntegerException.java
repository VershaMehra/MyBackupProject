package TryAnException;

public class NotIntegerException extends Exception {
public String getMessage() 
{
	return "Not a number";
}
}
