package TryAnException;

public class InvalidException extends Exception{
	public String getMessage()
	{
		
	return "infinte value";
	
	
	}
}
