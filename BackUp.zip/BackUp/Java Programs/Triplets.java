
public class Triplets {

	public static void printTriplets(int[ ] data) {
		
		int l=data.length;
		String str="";
		for(int i=0;i<l-2;i++)
		{
			for(int j=i+1;j<l-1;j++)
			{
				for(int k=j+1;k<l;k++)
				{
					if(data[i]+data[j] == data[k])
					{
						str=str+"<" +data[i]+data[j]+data[k]+ ">";
					}
				}
			}
		}
		System.out.println(str);
	}
	

	
	public static void main(String[]args)
	{
		int[] data={1,2,3,4,5,7,9};
		printTriplets(data);
	}
}
