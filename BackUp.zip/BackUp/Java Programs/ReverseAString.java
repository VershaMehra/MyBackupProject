
public class ReverseAString {

	public static void main(String[] args) {


String s[]={"ab","cd","ef"};
String rev[]=new String[s.length];
int idx=0;

for(int i=s.length-1;i>=0;i--)
{
	rev[idx++]=s[i];	
}

for(int i=0;i<rev.length;i++)
{
	System.out.print(rev[i]+" ");
}
}
}
	
	
