package sortingvks;

public class Test {
	static{
		System.out.println("I am Static block");
	}
	{
		System.out.println("I am non static ");
	}
public static void main(String[] args) {
	new Test();
	new Test();
}
}
