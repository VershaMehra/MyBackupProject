package sortingvks;

public class array {

	public static void main(String[] args) {
	
		//copy of arr into arr1
		int[]arr={4,3,6,8,9};
		int[]arr1=new int[5];
		for(int i=0;i<arr.length;i++)
		{
			arr1[i]=arr[i];
			System.out.println(arr1[i]);
		}

	}

}
