package sortingvks;

public class MergeSort {
	
	
	public  void sort(int[] arr, int low, int high) 
    {
		
		   
		           if( low < high )
		           {
		           int mid = (high + low ) / 2 ;         
		           sort (arr, low , mid ) ;                 
		           sort (arr,mid+1 , high ) ;
		           merge(arr,low,mid,high);
		           }
		           else return;
    }
	void merge(int arr[],int low , int mid ,int high )
  {
		int k=0;
		int p=low,q=mid+1;
		int a[]=new int[high-low+1];
		for(int i=low;i<=high;i++)
		{
			if(p>mid)
				a[k++]=arr[q++];
			else if(q>high)
				a[k++]=arr[p++];
			else if(arr[p]<arr[q])
				a[k++]=arr[p++];
			else
				a[k++]=arr[q++];
		}
		for(int i=0;i<k;i++)
		{
			arr[low++]=a[i];
  }
    }
}
