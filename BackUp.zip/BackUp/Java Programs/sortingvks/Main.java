package sortingvks;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a[] = {54,67,9,35,44,11};
		MergeSort s = new MergeSort();
		s.sort(a, 0,a.length-1);
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}

	}

}