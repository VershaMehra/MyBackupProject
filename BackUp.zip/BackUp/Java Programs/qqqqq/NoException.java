package qqqqq;

public class NoException extends Exception {

	
	public String getMessage()
	{
		return "no is greater than 100";
	}
	
}
