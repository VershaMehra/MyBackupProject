package qqqqq;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a no");
		try{
		int n=sc.nextInt();
		if(n>100)
		{
			throw new NoException();
		}
		System.out.println("number is:"+n);
		
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
