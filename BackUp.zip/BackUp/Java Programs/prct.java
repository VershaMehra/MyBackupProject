import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;


public class prct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int id=0;
		System.out.println("enter no of students");
		int n=Integer.parseInt(args[0]);
System.out.println(args[0]);

LinkedHashSet<Integer> hs = new LinkedHashSet<Integer>();
Scanner sc=new Scanner(System.in);
System.out.println("enter ids");


	while(hs.size()<=n)
	{
		id=sc.nextInt();
		hs.add(id);
	}
	//System.out.println(hs);

	Iterator<Integer> itr=hs.iterator();
	while(itr.hasNext())
		System.out.println(itr.next());
	
	
	}

		
		
		
	}


