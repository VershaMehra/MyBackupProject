
public class CustomVershaException extends Exception{
	public CustomVershaException() {
super();	}

}
