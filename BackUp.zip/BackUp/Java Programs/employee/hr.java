package employee;

public class hr extends employee {

	public hr(String name, String phone, String address,String dept ) {
		super(name, phone, address,dept);
		
	}

}
