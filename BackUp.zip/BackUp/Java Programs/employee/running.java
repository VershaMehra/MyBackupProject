package employee;

import java.util.Scanner;

public class running {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("no of employees");
		int n=sc.nextInt();
		int h=0,a=0,t=0,s=0;
		employee e[]=new employee[n];
		String emp[][]=new String[n][4];
		int i;
		for(i=0;i<n;i++)
		{
			
			for(int j=0;j<4;j++)
			{
				emp[i][j]=sc.next();
			}
		}
		
		
		for(i=0;i<n;i++)
		{
		  if(emp[i][4].equals("admin"))
				  {
					  e[i]=new admin(emp[i][0],emp[i][1],emp[i][2],emp[i][3]);
					  a++;
				  }
		}
	    for(i=0;i<n;i++)
	    {
	    	if(emp[i][4].equals("hr"))
	    			{
	    		 e[i]=new hr(emp[i][0],emp[i][1],emp[i][2],emp[i][3]);
	    		 h++;
	    			}
	    }
	    for(i=0;i<n;i++)
		{
		  if(emp[i][4].equals("it"))
				  {
					  e[i]=new it(emp[i][0],emp[i][1],emp[i][2],emp[i][3]);
					  t++;
				  }
		}
	    for(i=0;i<n;i++)
		{
		  if(emp[i][4].equals("security"))
				  {
					  e[i]=new security(emp[i][0],emp[i][1],emp[i][2],emp[i][3]);
					  s++;
				  }
		}
	    
	    System.out.println("admin"+a);
	    System.out.println("hr"+h);
	    System.out.println("it"+a);
	    System.out.println("security"+a);
	    System.out.println("enter Department");
	    String m=sc.next();
	    for(i=0;i<n;i++)
	    {
	    	if(m.equals(e[1].dept))
	    	{
	    		e[i].display();
	    	
	    		System.out.println();
	    	}
	    }
	    sc.close();
	    }
	}    	
		
	
	
