package employee;

public abstract class employee {
	
	String name;
	String phone;
	String address;
	String dept;

	public employee(String name,String phone,String address,String dept )
	{
		this.name=name;
		this.phone=phone;
		this.address=address;
		this.dept=dept;
	}
	public void display(){
		
		System.out.println("name"+name);
		System.out.println("phone"+address);
		System.out.println("address"+address);
		System.out.println("dept"+dept);
	}
	

}
