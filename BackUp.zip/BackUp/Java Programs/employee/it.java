package employee;

public class it extends employee{

	public it(String name, String phone, String address,String dept ) {
		super(name, phone, address,dept);
		
	}

}
