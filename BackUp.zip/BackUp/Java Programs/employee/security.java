package employee;

public class security extends employee{

	public security(String name, String phone, String address,String dept ) {
		super(name, phone, address,dept);
	
	}

}
