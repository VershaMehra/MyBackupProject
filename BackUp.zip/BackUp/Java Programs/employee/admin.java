package employee;

public class admin extends employee{

	public admin(String name, String phone, String address,String dept) {
		super(name, phone, address,dept);
		
	}
  
}
