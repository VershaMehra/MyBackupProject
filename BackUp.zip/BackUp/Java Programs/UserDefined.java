
public class UserDefined {

	public static void main(String[] args) {
	
		try{
			
		ExceptionHandle.exception(args);
	
			System.out.println(args[0]);
		}
		catch(InvalidException3 e){
			System.out.println(e);;
			
		}
	
}
}