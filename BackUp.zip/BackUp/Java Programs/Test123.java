
public class Test123 {

	public static void main(String[] args) {

		int n = 23;
		int a = 0;
		int x;
		int b[] = new int[3];
		String s;
		try {
			throw new NullPointerException();
			// b[4]=2;
			// System.out.println(n/a);
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("vivek is troubling at ni8");
		}
		catch (ArithmeticException e) {
			e.printStackTrace();
			System.out.println("works");

		}  
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("We dont know");
		}
		
		
	}

}
