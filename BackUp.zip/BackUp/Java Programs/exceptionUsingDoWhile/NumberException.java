package exceptionUsingDoWhile;

public class NumberException extends Exception {

	public String getMessage()
	{
		return "Invalid Number pls enter again";
	}
}
