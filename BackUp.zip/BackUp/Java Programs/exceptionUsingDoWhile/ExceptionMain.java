package exceptionUsingDoWhile;

import java.util.Scanner;

public class ExceptionMain {

	public static void main(String[] args) {
		boolean flag;
	do{
		flag=false;
			
		System.out.println("Enter a number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		flag=Number1.employee(n);
		if(flag==false)
		System.out.println("entered number is "+n);
		
	}while(flag==true);
		

	}
}
