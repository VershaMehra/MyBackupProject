package exceptionUsingDoWhile;

import exception.InvalidException;

public class Number1 {

	static boolean employee(int number) {
		
		if(number>100)
		{
			NumberException ie=new NumberException();
			System.out.println(ie.getMessage());
			return true;
		}
		return false;
	}
}
