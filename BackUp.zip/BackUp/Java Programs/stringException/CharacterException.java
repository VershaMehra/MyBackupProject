package stringException;

public class CharacterException extends Exception{
	
	public String getMessage()
	{
		return "enter only alphabets";
	}

}
