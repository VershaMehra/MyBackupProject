package stringException;

import java.util.Scanner;

public class CheckingAlphabets {

	public static void main(String[] args) {

		boolean flag;
	Scanner sc=new Scanner(System.in);
	 do{
	System.out.println("enter a string");
	String a=sc.nextLine();
	
	try{
	for(int i=0;i<a.length();i++)
	{
		char ch=a.charAt(i);
		if(!(ch>='a'&&ch<='z'||ch>='A'&&ch<='Z'||ch==' '))
		{
			throw new CharacterException();
		}
	
	}
	
		System.out.println(a);
	flag=false;
	//break;
	}
	catch(CharacterException e)
	{
		System.out.println(e.getMessage());
		flag=true;
	}
	 }while(flag);
		
	}

}
