

public class ExceptionHandle {
	
	static void exception(String[] args)throws InvalidException3 {
		if(args.length==0)
		 {
			 throw  new InvalidException3();
		 }
		 
	}

}
	 class InvalidException3 extends Exception{
			
			InvalidException3()
			{
				super("no value");
			}
		}