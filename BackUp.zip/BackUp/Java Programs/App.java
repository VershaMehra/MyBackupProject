import java.util.Scanner;

public class App extends Thread {
	public void run() {
		if (getName().equals("add"))
			add();
		else
			print();
	}

	public void add() {
		Scanner scan = new Scanner(System.in);
		System.out.println("enter a value");
		int a = scan.nextInt();
		System.out.println("enter b value");
		int b = scan.nextInt();
		int c = a + b;
		System.out.println(c);
	}

	public void print() {

		for (int i = 0; i < 5; i++) {
			System.out.println("Versha Mehra");
		}
	}
}
