function insertdata()
{
    var t1=new Date();
    
    var t2=document.f1.textentered.value;
   if(t2!=""){
       localStorage.setItem(JSON.stringify(t1),JSON.stringify(t2));
        alert("Success");
   

   }
   else{
    alert("Enter input");     
   }
}
function viewdata()
{
    var curdate=new Date();
    for(var i=0;i<localStorage.length;i++)
    {
        var pdt=JSON.parse(localStorage.key(i));
        var year=parseInt(pdt.substring(0,4));
        var mn=parseInt(pdt.substring(5,7));
        var d=parseInt(pdt.substring(8,10));
        var hr=parseInt(pdt.substring(11,13));
        var min=parseInt(pdt.substring(14,16));
        var sec=parseInt(pdt.substring(17,19));

        var cyear=curdate.getFullYear();
        var cmn=curdate.getMonth()+1;
        var cd=curdate.getDate();
        var chr=curdate.getHours();
        var cmin=curdate.getMinutes();
        var csec=curdate.getSeconds();
        if((cyear-year)!=0&&(cyear>year))
        {
            document.write("was written "+(cyear-year)+"years ago");

        }
        else if((mn-cmn)!=0&&(mn>cmn))
        {
            document.write("was written "+(mn-cmn)+"months ago");
            
        }
        else if((d-cd)!=0&&(d>cd))
        {
            document.write("was written" +(d-cd)+"days ago");
            
        }
       else if((hr-chr)!=0&&(hr>chr))
        {
            document.write("was written" +(hr-chr)+"hrs ago");
            
        }
       else if((min-cmin)!=0&&(min>cmin))
        {
            document.write("was written "+(min-cmin)+"mins ago");
            
        }
        else{
            document.write("was written" +(sec-csec)+"secs ago");
        }
        var obj1=JSON.parse(localStorage.getItem(localStorage.key(i)));
        document.write("</br>"+obj1+"</br>"+"<hr>");
    }
}