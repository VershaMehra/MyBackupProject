//Mobiles details
var obj = {
    "data": [
        { "Manufacturer": "Apple", "Storage": "32GB", "OS": "iOS", "Price": "Rs.50,000" },
        { "Manufacturer": "Apple", "Storage": "32GB", "OS": "iOS", "Price": "Rs.40,000" },
        { "Manufacturer": "Apple", "Storage": "16GB", "OS": "iOS", "Price": "Rs.30,000" },
        { "Manufacturer": "Samsung", "Storage": "16GB", "OS": "Android", "Price": "Rs.50,000" },
        { "Manufacturer": "Samsung", "Storage": "32GB", "OS": "Android", "Price": "Rs.40,000" },
        { "Manufacturer": "HTC", "Storage": "16GB", "OS": "Android", "Price": "Rs.50,000" },
        { "Manufacturer": "HTC", "Storage": "32GB", "OS": "Android", "Price": "Rs.40,000" },
        { "Manufacturer": "Nokia", "Storage": "16GB", "OS": "Windows", "Price": "Rs.50,000" },
        { "Manufacturer": "Nokia", "Storage": "32GB", "OS": "Windows", "Price": "Rs.40,000" },
        { "Manufacturer": "Sony", "Storage": "16GB", "OS": "Android", "Price": "Rs.50,000" },
        { "Manufacturer": "Sony", "Storage": "32GB", "OS": "Android", "Price": "Rs.40,000" },
        { "Manufacturer": "HTC", "Storage": "16GB", "OS": "Android", "Price": "Rs.60,000" },
    ]
}

//Displaying details in footer
for (var i = 0; i < obj.data.length; i++) {
    let num = new Number(i + 1)
    var divId = document.getElementById(num.toString())
    for (var keys in obj.data[i]) {
        divId.innerHTML = divId.innerHTML + "<br/>" + "<b>" + keys + "</b>" + " : " + obj.data[i][keys];
    }
}

//clear filter
function filter() {
    var categories = ["htc", "nokia", "samsung", "sony", "apple", "16gb", "32gb", "ios", "android", "windows"];
    for (let i = 0; i < 10; i++) {
        document.getElementsByClassName("cb")[i].checked = false;
        $("." + categories[i]).fadeTo("slow", 1);

    }

}

//modal styling
function close_modal() 
{
    var modal_box = document.getElementById("modal_box").style;
    modal_box.display = "none";
    modal_box.position = "fixed";
    modal_box.height = "600px";
    modal_box.width = "33%";
    modal_box.boxShadow = "5px 5px 5px #337ae7";
    modal_box.border = "1px solid #337ab7";
    modal_box.marginLeft = "33%";
    modal_box.marginTop = "5%";
    modal_box.backgroundColor = "#fff";
    modal_box.zIndex = 1;
}

//modal body
function zoom(val1, val2, desc) 
{
    document.getElementById("modal_box").style.display = "block";
    document.getElementsByClassName("container")[0].innerHTML = "<center><h4>" + val2 + "</h4></center><button type=button style = \"float:right;\" onclick = close_modal() class=btn btn-default data-dismiss=modal>&times;</button><img src = " + val1 + " height = 60% width = 100%>  <br><br> <b>Description:</b><br>" + desc;
}

//fadein and fadeout

function indfil(val)
{
    let flag = 0;
    let mcategories = ["apple", "samsung", "htc", "nokia", "sony"];
    let scategories = ["16gb", "32gb"];
    let ocategories = ["android", "ios","windows"];

    if(val=="apple"||val=="samsung"||val=="htc"||val=="nokia"||val=="sony")
        categories=mcategories;
    if(val=="16gb"||val=="32gb")
        categories=scategories;
    if(val=="android"||val=="ios"||val=="windows")
        categories=ocategories;

    for (let j in categories) 
    {
        if (document.getElementById(categories[j]).checked == false) 
        {
            $("." + categories[j]).fadeTo("slow", 0.1);
        }
        else 
        {
            $("." + categories[j]).fadeTo("slow", 1);
            ++flag;
        }
    }
    if (flag == 0) 
    {
        for (let j in categories) 
        {
            $("." + categories[j]).fadeTo("slow", 1);
        }
    }
}