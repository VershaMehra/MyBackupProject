package com.mindtree.DaoImpl;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mindtree.Dao.MainDao;
import com.mindtree.Entity.NewUser;

public class MainDaoImpl implements MainDao {
	
	
	
	public void add(NewUser nu)
	{
		
		Configuration cfg=new Configuration();
		cfg.configure(); 
		SessionFactory factory=cfg.buildSessionFactory();  
		Session session=factory.openSession();  
	    
		session.save(nu);
		Transaction t=session.beginTransaction();
		t.commit();
		
		
	
}
}
