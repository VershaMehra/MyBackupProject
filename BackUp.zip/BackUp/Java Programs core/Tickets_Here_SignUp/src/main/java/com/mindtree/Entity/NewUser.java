package com.mindtree.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class NewUser {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int uid;
	String username, password, emailid;
	long phno;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public long getPhno() {
		return phno;
	}

	public void setPhno(long phno2) {
		this.phno = phno2;
	}
	@Override
	public String toString() {
		return "NewUser [uid=" + uid + ", username=" + username + ", password=" + password + ", emailid=" + emailid
				+ ", phno=" + phno + "]";
	}
}
