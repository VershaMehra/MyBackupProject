package com.mindtree.serviceimpl;

import com.mindtree.Dao.MainDao;
import com.mindtree.DaoImpl.MainDaoImpl;
import com.mindtree.Entity.NewUser;
import com.mindtree.service.MainService;

public class MainServiceImpl implements MainService {

	MainDao dao=new MainDaoImpl(); 	//upcasting or Loose Coupling
	
	public boolean add(NewUser nu)
	{
		try
		{
		 	dao.add(nu);
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		
	}
}
