package com.mindtree.service;

import com.mindtree.Entity.NewUser;

public interface MainService {
boolean add(NewUser nu);
}
