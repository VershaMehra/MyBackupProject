package com.mindtree.Dao;

import com.mindtree.Entity.NewUser;

public interface MainDao {
void add(NewUser nu);
}
