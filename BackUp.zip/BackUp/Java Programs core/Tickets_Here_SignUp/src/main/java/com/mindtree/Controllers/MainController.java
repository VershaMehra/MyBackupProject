package com.mindtree.Controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.Entity.NewUser;
import com.mindtree.service.MainService;
import com.mindtree.serviceimpl.MainServiceImpl;

@Controller
public class MainController 
{
	MainService ms=new MainServiceImpl();   
	
@RequestMapping("/index")
public void signup(HttpServletRequest req,HttpServletResponse res)
{
	NewUser nu=new NewUser();
	String username=req.getParameter("username");
	String password=req.getParameter("password");
	String emailid=req.getParameter("email");
	long phno=Long.parseLong(req.getParameter("contact"));
	nu.setEmailid(emailid);
	nu.setPassword(password);
	nu.setPhno(phno);
	nu.setUsername(username);
	boolean flag=ms.add(nu);
	if(flag==true)
	{
		System.out.println("user added succesfully");
	
	}
	else
	{
		System.out.println("Invalid details");
	}
}

	

}
