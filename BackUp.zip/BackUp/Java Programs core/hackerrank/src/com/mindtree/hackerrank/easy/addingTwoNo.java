package com.mindtree.hackerrank.easy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class addingTwoNo {
	 static int addNumbers(float a, float b) {
         float sum=a+b;
       sum=(float) Math.floor(sum);
        return (int) sum;
        
        

    }
	 public static void main(String[] args) throws IOException {
	        Scanner in = new Scanner(System.in);
	        final String fileName = System.getenv("OUTPUT_PATH");
	        BufferedWriter bw = null;
	        if (fileName != null) {
	            bw = new BufferedWriter(new FileWriter(fileName));
	        }
	        else {
	            bw = new BufferedWriter(new OutputStreamWriter(System.out));
	        }

	        int res;
	        float a;
	        a = Float.parseFloat(in.nextLine().trim());

	        float b;
	        b = Float.parseFloat(in.nextLine().trim());

	        res = addNumbers(a, b);
	        bw.write(String.valueOf(res));
	        bw.newLine();

	        bw.close();
	    }

}
