package com.mindtree.hackerrank.mediam;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class maxdifference {
	  static int maxDifference(int[] a) {
		  
	        int max_diff =0;
	        int i, j;
	        int max=a[0];
	        for (i = 0; i < a.length; i++) 
	        {
	        	if(max<a[i])
	        		max=a[i];
	        		
	        }
	        if(max==a[0])
        		
        				max_diff=-1;
        				
        	    
	        for (i = 0; i < a.length; i++) 
	        {
	            for (j = i + 1; j < a.length; j++) 
	            {
	            	
	                if (a[j] - a[i] > max_diff)
	                    max_diff = a[j] - a[i];
	            }
	        }
	        return max_diff;
	    }

	  public static void main(String[] args) throws IOException {
	        Scanner in = new Scanner(System.in);
	        final String fileName = System.getenv("OUTPUT_PATH");
	        BufferedWriter bw = null;
	        if (fileName != null) {
	            bw = new BufferedWriter(new FileWriter(fileName));
	        }
	        else {
	            bw = new BufferedWriter(new OutputStreamWriter(System.out));
	        }

	        int res;
	        int a_size = 0;
	        a_size = Integer.parseInt(in.nextLine().trim());

	        int[] a = new int[a_size];
	        for(int i = 0; i < a_size; i++) {
	            int a_item;
	            a_item = Integer.parseInt(in.nextLine().trim());
	            a[i] = a_item;
	        }

	        res = maxDifference(a);
	        bw.write(String.valueOf(res));
	        bw.newLine();

	        bw.close();
	    }
	}


