package com.mindtree.hackerrank.easy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class powerOfTwo {

	 static int[] isPowerOf2(int[] nums) {
	        int[] res=new int[nums.length];
	     
	        for(int i=0;i<nums.length;i++)
	        {
	            for(int n=1;n<100;n++)
	            {
	            	int a=(int) Math.pow(2,n);
	                 
	                 if(nums[i]==a)
	                 {
	                  res[i]=1; 
	                  break;
	                 }
	                else
	                    res[i]=0;
	                
	            }
	           
	        }
	            return res;
	    }
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(System.in);
        final String fileName = System.getenv("OUTPUT_PATH");
        BufferedWriter bw = null;
        if (fileName != null) {
            bw = new BufferedWriter(new FileWriter(fileName));
        }
        else {
            bw = new BufferedWriter(new OutputStreamWriter(System.out));
        }

        int[] res;
        int nums_size = 0;
        nums_size = Integer.parseInt(in.nextLine().trim());

        int[] nums = new int[nums_size];
        for(int i = 0; i < nums_size; i++) {
            int nums_item;
            nums_item = Integer.parseInt(in.nextLine().trim());
            nums[i] = nums_item;
        }

        res = isPowerOf2(nums);
        for(int res_i = 0; res_i < res.length; res_i++) {
            bw.write(String.valueOf(res[res_i]));
            bw.newLine();
        }

        bw.close();
    }
}


