package com.mindtree.hackerrank.mediam;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class uniquearray {
	 static int getMinimumUniqueSum(int[] arr) {
	      int sum=0;
       for(int i=0;i<arr.length;i++)
       {   
          for(int j=i+1;j<arr.length;j++)
           {
       	   if(arr[i]==arr[j])
       	   {
       		   arr[j]=arr[j]+1;
       	   }
           }
        } 
       for(int i=0;i<arr.length;i++)
       {
       	sum=sum+arr[i];
       }
  return sum;
  }
	 public static void main(String[] args) throws IOException {
	        Scanner in = new Scanner(System.in);
	        final String fileName = System.getenv("OUTPUT_PATH");
	        BufferedWriter bw = null;
	        if (fileName != null) {
	            bw = new BufferedWriter(new FileWriter(fileName));
	        }
	        else {
	            bw = new BufferedWriter(new OutputStreamWriter(System.out));
	        }

	        int res;
	        int arr_size = 0;
	        arr_size = Integer.parseInt(in.nextLine().trim());

	        int[] arr = new int[arr_size];
	        for(int i = 0; i < arr_size; i++) {
	            int arr_item;
	            arr_item = Integer.parseInt(in.nextLine().trim());
	            arr[i] = arr_item;
	        }

	        res = getMinimumUniqueSum(arr);
	        bw.write(String.valueOf(res));
	        bw.newLine();

	        bw.close();
	    }
	}



