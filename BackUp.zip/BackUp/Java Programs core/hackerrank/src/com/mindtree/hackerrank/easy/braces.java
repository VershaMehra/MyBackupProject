package com.mindtree.hackerrank.easy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.util.Stack;

public class braces {
	 static String[] braces(String[] values) {
		    String[]res=new String[values.length];
		    String s1="YES";
        int k=0;
	        Stack<Character> stack  = new Stack<Character>();
	        for(k=0;k<values.length;k++)
	        {
	        	String temp=values[k];	
	        	for(int i=0;i<temp.length();i++)
	        	{
	        		char c=temp.charAt(i);
	        		if(c=='{'||c=='('||c=='[')
	        			{
	        				stack.push(c);
	        			s1="YES";
	        			
	        			}
	        		else if(c=='}')
	        			if(stack.isEmpty()||stack.pop()!='{')
	        				s1="NO";
	        		
	        			else if(c==')')
		        			if(stack.isEmpty()||stack.pop()!='(')
		        				s1="NO";
	        		
		        			else if(c==']')
			        			if(stack.isEmpty()||stack.pop()!='[')
			        				s1="NO";
	        	}
                                
                res[k]=s1;
	        }
	       
	        
	        return res;
	    }

    

	
	 public static void main(String[] args) throws IOException {
	        Scanner in = new Scanner(System.in);
	        final String fileName = System.getenv("OUTPUT_PATH");
	        BufferedWriter bw = null;
	        if (fileName != null) {
	            bw = new BufferedWriter(new FileWriter(fileName));
	        }
	        else {
	            bw = new BufferedWriter(new OutputStreamWriter(System.out));
	        }

	        String[] res;
	        int values_size = 0;
	        values_size = Integer.parseInt(in.nextLine().trim());

	        String[] values = new String[values_size];
	        for(int i = 0; i < values_size; i++) {
	            String values_item;
	            try {
	                values_item = in.nextLine();
	            } catch (Exception e) {
	                values_item = null;
	            }
	            values[i] = values_item;
	        }

	        res = braces(values);
	        for(int res_i = 0; res_i < res.length; res_i++) {
	            bw.write(String.valueOf(res[res_i]));
	            bw.newLine();
	        }

	        bw.close();
	    }
}
