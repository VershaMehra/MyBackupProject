package com.mindtree.hackerrank.mediam;

import java.util.Arrays;

public class practice {
	public static void main(String[]args){
	
		  
		 
		  int[]a=new int[]{6,2,7,4,2};
		  Arrays.sort(a);
		 
		 
		 int n=0;
		 int[]temp=new int[5];
		  
		 /* for(int i=0;i<5;i++)
		  {
			System.out.println(a[i]);
		  }*/
		  for(int i=0;i<a.length-1;i++)
		  {
			  
                if(a[i]!=a[i+1])
                		{
                			temp[n]= a[i];
                			
                			n++;
                		}
               
			 }
		  
		  
			
			for (int i = 0; i<n; i++) {
				System.out.println(temp[i]);
			}
			System.out.println(temp[n]);
		


		  
		  
		  
		  
}
}