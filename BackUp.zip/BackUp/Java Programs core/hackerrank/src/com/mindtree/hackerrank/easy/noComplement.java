package com.mindtree.hackerrank.easy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class noComplement {

    static int getIntegerComplement(int n) {
      String str=Integer.toString(n,2);
		
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='1')
			
				sb.append("0");
			
			else
			
				sb.append("1");
			
		}
		str=sb.toString();
		int a=Integer.parseInt(str,2);
        return a;
		  

    }
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(System.in);
        final String fileName = System.getenv("OUTPUT_PATH");
        BufferedWriter bw = null;
        if (fileName != null) {
            bw = new BufferedWriter(new FileWriter(fileName));
        }
        else {
            bw = new BufferedWriter(new OutputStreamWriter(System.out));
        }

        int res;
        int n;
        n = Integer.parseInt(in.nextLine().trim());

        res = getIntegerComplement(n);
        bw.write(String.valueOf(res));
        bw.newLine();

        bw.close();
    }
}

}
