package com.mindtree.hackerrank.easy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class lastsecondLast {
	  static String lastLetters(String word) {
		  int length=word.length();
		 		 char a=word.charAt(length-1);
		 		 char b=word.charAt(length-2);
		 		 String s = a+" "+b;
		 		 return s;
		     }
	  public static void main(String[] args) throws IOException {
	        Scanner in = new Scanner(System.in);
	        final String fileName = System.getenv("OUTPUT_PATH");
	        BufferedWriter bw = null;
	        if (fileName != null) {
	            bw = new BufferedWriter(new FileWriter(fileName));
	        }
	        else {
	            bw = new BufferedWriter(new OutputStreamWriter(System.out));
	        }

	        String res;
	        String word;
	        try {
	            word = in.nextLine();
	        } catch (Exception e) {
	            word = null;
	        }

	        res = lastLetters(word);
	        bw.write(res);
	        bw.newLine();

	        bw.close();
	    }
}
