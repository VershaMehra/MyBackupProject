package com.mindtree.hackerrank.easy;

import java.util.Scanner;

public class canYouSort {
	  static void customSort(int[] arr)
	  {
	        int[]res=new int[arr.length];
	        int[]j=new int[arr.length];
	        for(int i=0;i<arr.length;i++)
	           {
	            
	                j[i]=arr.length;
	            }
	            
	        res[j]=arr.sort(j);

	    System.out.println(res);
	  }



public static void main(String[] args)  {
    Scanner in = new Scanner(System.in);
    int arr_size = 0;
    arr_size = Integer.parseInt(in.nextLine().trim());

    int[] arr = new int[arr_size];
    for(int i = 0; i < arr_size; i++) {
        int arr_item;
        arr_item = Integer.parseInt(in.nextLine().trim());
        arr[i] = arr_item;
    }

    customSort(arr);
    
}
}