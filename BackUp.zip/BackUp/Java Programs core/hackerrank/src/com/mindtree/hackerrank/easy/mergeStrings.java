package com.mindtree.hackerrank.easy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class mergeStrings {
	 static String mergeStrings(String a, String b) {
		 int sl;
	        String s="";
	        int l1=a.length();
	        int l2=b.length();
	        if(l1<l2)
	            sl=l1;
	        else if(l2<l1)
	            sl=l2;
	        else
	            sl=l1;
	        int i;
	        for( i=0;i<sl;i++)
	        {
	            s=s+a.charAt(i);
	            s=s+b.charAt(i);
	        }
	        if(sl==l1)
	            s=s+b.substring(i);
	            else if(sl==l2)
	                s=s+a.substring(i);
	        return s;
		 


	    }
	 public static void main(String[] args) throws IOException{
	        Scanner in = new Scanner(System.in);
	        final String fileName = System.getenv("OUTPUT_PATH");
	        BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
	        String res;
	        String _a;
	        try {
	            _a = in.nextLine();
	        } catch (Exception e) {
	            _a = null;
	        }
	        
	        String _b;
	        try {
	            _b = in.nextLine();
	        } catch (Exception e) {
	            _b = null;
	        }
	        
	        res = mergeStrings(_a, _b);
	        bw.write(res);
	        bw.newLine();
	        
	        bw.close();
	    }

}
