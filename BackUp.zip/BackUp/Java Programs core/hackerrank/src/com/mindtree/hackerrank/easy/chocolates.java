package com.mindtree.hackerrank.easy;

import java.util.Scanner;

public class chocolates {
	 static void calculate(int[] arr) {
	        
	       
	        int sum=0;
	       
	        for(int i=0;i<arr.length;i++)
	        {
	        if((arr[i]%2)!=0)
	        {
	        	sum=sum+arr[i];
	 	       System.out.println(sum);
	        }
	        else
	        	System.out.println(sum);
	        }
	        

	    }


	
	 public static void main(String[] args)  {
	        Scanner in = new Scanner(System.in);
	        int arr_size = 0;
	        arr_size = Integer.parseInt(in.nextLine().trim());

	        int[] arr = new int[arr_size];
	        for(int i = 0; i < arr_size; i++) {
	            int arr_item;
	            arr_item = Integer.parseInt(in.nextLine().trim());
	            arr[i] = arr_item;
	        }

	        calculate(arr);
	        
	    }
	}

	

