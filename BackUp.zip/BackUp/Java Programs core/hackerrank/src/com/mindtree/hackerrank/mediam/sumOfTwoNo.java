package com.mindtree.hackerrank.mediam;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Scanner;

public class sumOfTwoNo {
	  static int numberOfPairs(int[] a, long k) {
		  int[]temp=new int[20];
		 
		  int count=0;
		Arrays.sort(a);
		 
		  int n=0;
		 
		  
		  for(int i=0;i<a.length-1;i++)
		  {
			  
                if(a[i]!=a[i+1])
                		{
                			temp[n]= a[i];
                			
                			n++;
                		}
               
			 }
		  
		  
			
			for (int i = 0; i<n; i++) {
				System.out.println(temp[i]);
			}
		  for(int p=0;p<temp.length;p++)
		  {
			 for(int q=0;q<=temp.length;q++)
			 {
				 if((p+temp[q])==k)
					 count++;
			 }
                
		 }
					return count;		  
	    }
	  public static void main(String[] args) throws IOException {
	        Scanner in = new Scanner(System.in);
	        final String fileName = System.getenv("OUTPUT_PATH");
	        BufferedWriter bw = null;
	        if (fileName != null) {
	            bw = new BufferedWriter(new FileWriter(fileName));
	        }
	        else {
	            bw = new BufferedWriter(new OutputStreamWriter(System.out));
	        }

	        int res;
	        int a_size = 0;
	        a_size = Integer.parseInt(in.nextLine().trim());

	        int[] a = new int[a_size];
	        for(int i = 0; i < a_size; i++) {
	            int a_item;
	            a_item = Integer.parseInt(in.nextLine().trim());
	            a[i] = a_item;
	        }

	        long k;
	        k = Long.parseLong(in.nextLine().trim());

	        res = numberOfPairs(a, k);
	        bw.write(String.valueOf(res));
	        bw.newLine();

	        bw.close();
	    }
	}



