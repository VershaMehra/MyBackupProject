package com.mindtree.hackerrank.hard;

import java.util.Scanner;

public class recursion {
	static int fac(int n)
	{
		if(n==1)
			return 1;
		else
		return (n*fac(n-1));
	}
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		int var=sc.nextInt();
		int fact=1;
		int number = 0;
		
	fact=fac(var);
 System.out.println(fact);
	}
}
