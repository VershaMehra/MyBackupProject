package com.mindtree.hackerrank.easy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class puzzle {
	 static int countHoles(int num) {
         int count=0;
   while(num>0)
    {
	  int div=num/10;
    int mod=num%10;
   // if(mod==1||mod==2||mod==3||mod==5||mod==7)
    //	count=count+0;
    //else
        if(mod==0||mod==4||mod==6||mod==9)
    	count++;
    else if (mod==8)
    	count=count+2;
    num=div;
    }
   return count;

}
        

   
	 public static void main(String[] args) throws IOException {
	        Scanner in = new Scanner(System.in);
	        final String fileName = System.getenv("OUTPUT_PATH");
	        BufferedWriter bw = null;
	        if (fileName != null) {
	            bw = new BufferedWriter(new FileWriter(fileName));
	        }
	        else {
	            bw = new BufferedWriter(new OutputStreamWriter(System.out));
	        }

	        int res;
	        int num;
	        num = Integer.parseInt(in.nextLine().trim());

	        res = countHoles(num);
	        bw.write(String.valueOf(res));
	        bw.newLine();

	        bw.close();
	    }

}
