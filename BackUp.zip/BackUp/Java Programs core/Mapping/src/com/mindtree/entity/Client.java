package com.mindtree.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {

	public static void main(String[] args) {
	
		 Configuration cfg=new Configuration();  
		    cfg.configure();
		    SessionFactory factory=cfg.buildSessionFactory();  
		    Session session=factory.openSession();  
		    Transaction t=session.beginTransaction();  
		    
		    
		    Department d1=new Department();
		    d1.setDeptname("IT");

		    Employee1 e1=new Employee1();
		    e1.setEname("ssss");
		    e1.setDepartment(d1);
		    
		    
		    
		    
		   session.save(d1);
		    session.save(e1);
		    t.commit();
		    
		    //retrieving data
		  /*  Employee e;
		    e=(Employee)session.get(Employee1.class,101);   	
		    System.out.println(e); */
		    
		    //displaying data
		   /* e.setename("neha");
		    session.update(e);	*/ 
		    
		    
		    // for deleting data
		  /* Object ob=session.load(Employee1.class,101);
		   session.delete(ob);*/
	    
		    
       //t.commit();
		    session.close();
		      
		  //  System.out.println("successfully saved");  
		      
		

		

	}

}
