package com.hibernate.Dao.Daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.hibernate.Dao.EmployeeDao;
import com.hibernate.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private SessionFactory sessionFactory;
	private Session session;
	
	public EmployeeDaoImpl()
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cgf.xml");
		sessionFactory=cfg.buildSessionFactory();
		session=sessionFactory.openSession();
	}
	
	public boolean addEmployee(Employee employee)	
	{
		try{
		Transaction t=session.beginTransaction();
		session.save(employee);
		t.commit();
		return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
	
	  public boolean deleteEmployee (int eno)
	  {
		  try{
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("Delete from Employee where eno=:num");
		q.setParameter("num",eno);
		int x=q.executeUpdate();
		if(x!=0)
			return true;
		else
			return false;
		  }
		  catch(Exception exp)
		  {
			  exp.printStackTrace();
			  return false;
		  }
	  }
	  public void updateEmployee(int eno,double salary)
	  {
		  try{
		Transaction t=session.beginTransaction();
		Query q=session.createQuery("update Employee set salary=:sal where eno=:num");
		q.setParameter("sal",salary);
		q.setParameter("num",eno);
		q.executeUpdate();
		  }
		  catch(Exception exp)
		  {
			  exp.printStackTrace();
		  }
	  }
	  
	  public List<Employee> getEmployeeList()
	  {
		  try{
		  Transaction t=session.beginTransaction();
		  Query q=session.createQuery("From Employee",Employee.class);
		  return q.getResultList();
		  }
		  catch(Exception exp)
		  {
			  exp.printStackTrace();
			  return null;
		  }
		  }
		  
	  
}
