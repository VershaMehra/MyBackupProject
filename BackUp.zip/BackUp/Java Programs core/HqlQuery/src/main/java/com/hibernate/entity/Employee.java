package com.hibernate.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
	public class Employee {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		int eno;
		String ename;
		double salary;

		public double getSalary() {
			return salary;
		}

		public void setSalary(double salary) {
			this.salary = salary;
		}

		public int getEno() {
			return eno;
		}

		public void setEno(int eno) {
			this.eno = eno;
		}

		public String getEname() {
			return ename;
		}

		public void setEname(String ename) {
			this.ename = ename;
		}

		@Override
		public String toString() {
			return "Employee [eno=" + eno + ", ename=" + ename + ", salary=" + salary + "]";
		}
	
	
}
