package com.hibernate.Dao;

import java.util.List;

import com.hibernate.entity.Employee;

public interface EmployeeDao {

	
	
    public boolean addEmployee (Employee employee);
    public boolean deleteEmployee (int eno);
    public void updateEmployee(int eno,double salary);
    public List<Employee> getEmployeeList();

}



