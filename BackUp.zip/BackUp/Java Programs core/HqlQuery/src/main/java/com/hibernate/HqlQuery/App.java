package com.hibernate.HqlQuery;

import java.util.Scanner;

import com.hibernate.Dao.EmployeeDao;
import com.hibernate.Dao.Daoimpl.EmployeeDaoImpl;

public class App 
{
    public static void main( String[] args )
    {
    	
    	EmployeeDao dao=new EmployeeDaoImpl();  // loose coupling
    	Scanner scan=new Scanner(System.in);
    	
    }
}
