import java.util.Scanner;

public class Demo {
public static void main(String[] args) throws InvalidException {
	Scanner scan=new Scanner(System.in);
	try
	{
		System.out.println("enter a number");
		int n=scan.nextInt();
		System.out.println(n);
	}
	catch(Exception e)
	{
		throw new InvalidException("Check Your Datatype ",e);
	}
}
}
