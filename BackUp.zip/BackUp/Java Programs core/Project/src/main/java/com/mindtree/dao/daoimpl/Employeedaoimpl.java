package com.mindtree.dao.daoimpl;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.dao.Employeedao;
import com.mindtree.entity.Employee;

public class Employeedaoimpl implements Employeedao {
@Autowired(required=true)
private SessionFactory sessionFactory;
	public boolean addemployee(Employee employee) {
		try {
			sessionFactory.getCurrentSession().persist(employee);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean deleteemployee(Employee employee) {
		try {
			sessionFactory.getCurrentSession().delete(employee);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public void updateemployee(Employee employee) {

	}

	public List<Employee> getEmployeeList() {

		try {
			String select = "From Employee";
			Query<Employee> query = sessionFactory.getCurrentSession().createQuery(select, Employee.class);
			return query.getEmployeeList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
