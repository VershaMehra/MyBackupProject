package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Employee;

public interface Employeedao {
	
    public boolean addemployee (Employee employee);
    public boolean deleteemployee (Employee employee);
    public void updateemployee(Employee employee);
    public List<Employee> getEmployeeList();

}

