package com.mindtree.entity;


	import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;  
	import org.hibernate.SessionFactory;  
	import org.hibernate.Transaction;  
	import org.hibernate.cfg.Configuration;  

	public class User {
	public static void main(String[] args) {
		    Configuration cfg=new Configuration();  
		    cfg.configure();//populates the data of the configuration file  
		      
		    SessionFactory factory=cfg.buildSessionFactory();  
		      
		    Session session=factory.openSession();  
		      
		    Transaction t=session.beginTransaction();  
		          
		    
		    
		   Employee e1=new Employee();
		    
		  /* e1.setempno(103);  
		    e1.setempname("Versha Mehra");  
		    e1.setemail("versha.mehra1995@gmail.com");  
		    e1.setdob(new Date(95,10,13));
		    e1.setsal(100000);*/
		    
		    
		/* e1.setempno(102);
		 e1.setempname("monu");
		 e1.setemail("monu@gmail.com");
		 e1.setdob(new Date(94,8,10));
		 e1.setsal(97867);*/
		    
		    
		  /*  session.save(e1);
		    t.commit();
		    */
		    
		    
		    
		    
		    
		    //retrieving data
		   
		    Employee e;
		    e=(Employee)session.get(Employee.class,101);   	
		    System.out.println(e); 
		    
		    //displaying data
		    
		/* e.setempname("neha");
		    session.update(e);*/	
		    
		    
		    // for deleting data
		   
		/* Object ob=session.load(Employee.class,102);
		  Employee emp=(Employee)session.load(Employee.class,102);
		  session.delete(ob);*/
	    
		    
         t.commit();
		    session.close();
		      
		  //  System.out.println("successfully saved");  
		      
		

	}

}