package com.mindtree.entity;

import java.util.Date;

public class Employee {
	int empno;
	String empname;
	String email;
	Date dob;
	double sal;

	public int getempno() {
		return empno;
	}

	public void setempno(int empno) {
		this.empno = empno;
	}

	public String getempname() {
		return empname;
	}

	public void setempname(String empname) {
		this.empname = empname;
	}

	public String getemail() {
		return email;
	}

	public void setemail(String email) {
		this.email = email;
	}

	public Date getdob() {
		return dob;
	}

	public void setdob(Date dob) {
		this.dob = dob;
	}

	public double getsal() {
		return sal;
	}

	public void setsal(double sal) {
		this.sal = sal;
	}

	public String toString() {
		return empno + " " + empname + " " + email + " " + dob + " " + sal;
	}
}
