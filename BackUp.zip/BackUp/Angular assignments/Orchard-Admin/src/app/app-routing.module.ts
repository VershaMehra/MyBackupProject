import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserpageComponent } from "./userpage/userpage.component";
import { LeadComponent } from "./lead/lead.component";
import { CampusmindComponent } from "./campusmind/campusmind.component";
import { CapabilitiesComponent } from "./capabilities/capabilities.component";
import { UserRouteGuard } from "./user-routeguard.service";
import { LoginpageComponent } from "./loginpage/loginpage.component";



const routes: Routes = [
  {path : '', component: LoginpageComponent},
  {path : 'userpage', component : UserpageComponent,
    children:[
      {path: '', component:CapabilitiesComponent},
      {path : 'lead', canActivate:[UserRouteGuard],component:LeadComponent},
      {path : 'campusmind', component: CampusmindComponent},
      {path : 'capabilities', component:CapabilitiesComponent}
    ]
  },
  {path : 'logout',component: LoginpageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
