import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from "@angular/router";
import { UserRouteGuard } from "../user-routeguard.service";
declare var require: any;

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  test:any;
  mid:string;
  pwd:string;
  constructor(private router:Router,private routerGuard:UserRouteGuard) { }

  ngOnInit() 
  {
    this.test = require('../../jsonfiles/credentials.json');
  }

  Login()
  {
    if((this.mid==this.test[0].mid) && (this.pwd==this.test[0].password) && (this.test[0].role=='CampusMind'))
    {
      
      this.routerGuard.isUserAllowed(false);
      this.router.navigate(['userpage']);
    }
    else if((this.mid==this.test[1].mid) && (this.pwd==this.test[1].password) && (this.test[1].role=='Lead'))
    {
     
      this.router.navigate(['userpage']);
    }
    else
    {
     
      alert("Invalid Credentials");
    }
  
  }

  clear()
  {
    this.mid='';
    this.pwd='';
  }

}
