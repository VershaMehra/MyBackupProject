import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { UserRouteGuard } from "../user-routeguard.service";

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.css']
})
export class UserpageComponent implements OnInit {

  
  constructor(private router:Router,private routerGuard:UserRouteGuard) { }

  ngOnInit() {
  }

  logout()
  {
    this.routerGuard.isAllowed=true;;
      this.router.navigate(['']);
  }

}
