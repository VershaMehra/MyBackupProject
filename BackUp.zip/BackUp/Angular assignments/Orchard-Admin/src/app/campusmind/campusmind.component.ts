import { Component, OnInit } from '@angular/core';
declare var require: any;
@Component({
  selector: 'app-campusmind',
  templateUrl: './campusmind.component.html',
  styleUrls: ['./campusmind.component.css']
})
export class CampusmindComponent implements OnInit {
test:any;
  constructor() { }

  ngOnInit() {
    this.test = require('../../jsonfiles/CampusMinds.json');
  }

}
