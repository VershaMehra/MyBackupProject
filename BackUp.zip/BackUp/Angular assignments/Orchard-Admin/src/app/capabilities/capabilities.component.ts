import { Component, OnInit } from '@angular/core';
declare var require: any;

@Component({
  selector: 'app-capabilities',
  templateUrl: './capabilities.component.html',
  styleUrls: ['./capabilities.component.css']
})
export class CapabilitiesComponent implements OnInit {

  test:any;
  constructor() { }

  ngOnInit() {
    this.test = require('../../jsonfiles/Capabilities.json');
  }

}
