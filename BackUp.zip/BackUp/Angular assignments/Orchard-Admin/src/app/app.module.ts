import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgModel } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClient } from '@angular/common/http';
import { UserpageComponent } from './userpage/userpage.component';
import { LeadComponent } from './lead/lead.component';
import { CampusmindComponent } from './campusmind/campusmind.component';
import { CapabilitiesComponent } from './capabilities/capabilities.component';
import { UserRouteGuard } from "./user-routeguard.service";
import { LoginpageComponent } from "./loginpage/loginpage.component";





@NgModule({
  declarations: [
    AppComponent,
    LoginpageComponent,
    UserpageComponent,
    LeadComponent,
    CampusmindComponent,
    CapabilitiesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [UserRouteGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
