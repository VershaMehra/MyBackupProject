export class Model {
    name: string;
    mid: string;
    feedback: string;
    date:Date;
    constructor(name : string, mid:string,feedback : string, date:Date)
    {
       this.name=name;
       this.mid=mid;
       this.feedback=feedback;
       this.date=date; 
    }
}