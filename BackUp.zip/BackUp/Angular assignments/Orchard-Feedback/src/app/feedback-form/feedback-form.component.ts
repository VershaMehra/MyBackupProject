import { Component, OnInit } from '@angular/core';
import { DataService } from "../data.service";
import { Model } from "../model";
@Component({
  selector: 'app-feedback-form',
  templateUrl: './feedback-form.component.html',
  styleUrls: ['./feedback-form.component.css']
})

export class FeedbackFormComponent implements OnInit {

name:string;
mid:string;
comments:string;

  constructor(private dataservice:DataService) { }

  ngOnInit() {
  }

  onSubmit()
  {
this.dataservice.feedback.push(new Model(this.name,this.mid,this.comments,new Date()));
  }
  clear()
  {
    this.name='';
    this.mid='';
    this.comments='';
  }


}
