import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Injectable()
export class DataService {

feedback = new Array();
  constructor() { }
goals = new  BehaviorSubject<any>(this.feedback);
goal= this.goals.asObservable();

}
