import { Component, OnInit } from '@angular/core';
import { DataService } from "../data.service";
import { Model } from "../model";

@Component({
  selector: 'app-feedback-comments',
  templateUrl: './feedback-comments.component.html',
  styleUrls: ['./feedback-comments.component.css']
})
export class FeedbackCommentsComponent implements OnInit {

  feedback:Model[];
  
  constructor(private dataService:DataService) { }

  ngOnInit() {
    this.dataService.goal.subscribe((data)=>{
      this.feedback=data;
    });
  }

}
